import 'dart:convert';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import '../../data/response_models/organizer_response_models/organizer_event_delete_model.dart';

class OrganizerEventDeleteRepo {
  static const String baseUrl = 'http://138.68.104.206:3000';
  final _storage = GetStorage();

  Future<OrganizerEventDeleteModel> deleteEvent(int eventId) async {
    try {
      final token = _storage.read('token') ?? '';

      final response = await http.delete(
        Uri.parse('$baseUrl/event/$eventId'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200  || response.statusCode == 201) {
        final Map<String, dynamic> responseData = json.decode(response.body);
        return OrganizerEventDeleteModel.fromJson(responseData);
      } else {
        throw Exception('Failed to delete event: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to delete event: $e');
    }
  }
}