import 'dart:convert';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import '../../data/request_models/organizer/organizer_create_event_venue_model.dart';

class OrganizerCreateEventVenueRepo {
  static const String baseUrl = 'http://138.68.104.206:3000';
  final _storage = GetStorage();

  Future<OrganizerCreateEventVenueModel> createEvent(Map<String, dynamic> data) async {
    try {
      final token = _storage.read('token') ?? '';

      final response = await http.post(
        Uri.parse('$baseUrl/event'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: json.encode(data),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        final Map<String, dynamic> responseData = json.decode(response.body);
        return OrganizerCreateEventVenueModel.fromJson(responseData);
      } else {
        throw Exception('Failed to create event: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to create event: $e');
    }
  }

  Future<OrganizerCreateEventVenueModel> updateEvent(int eventId, Map<String, dynamic> data) async {
    try {
      final token = _storage.read('token') ?? '';

      final response = await http.patch(
        Uri.parse('$baseUrl/event/$eventId'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: json.encode(data),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseData = json.decode(response.body);
        return OrganizerCreateEventVenueModel.fromJson(responseData);
      } else {
        throw Exception('Failed to update event: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to update event: $e');
    }
  }

  Future<OrganizerCreateEventVenueModel> getEvent(int eventId) async {
    try {
      final token = _storage.read('token') ?? '';

      final response = await http.get(
        Uri.parse('$baseUrl/event/$eventId'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        final Map<String, dynamic> responseData = json.decode(response.body);
        return OrganizerCreateEventVenueModel.fromJson(responseData);
      } else {
        throw Exception('Failed to get event: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to get event: $e');
    }
  }
}