import 'package:al_sharq_conference/custom_widgets/custom_drawer.dart';
import 'package:flutter/material.dart';
import 'package:al_sharq_conference/app_colors/app_colors.dart';
import 'package:al_sharq_conference/custom_widgets/custom_button.dart';
import 'package:al_sharq_conference/custom_widgets/app_text.dart';
import 'package:get/get.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../images/images.dart';
import '../../data/response_models/participant_response_model/speaker_part_in_participant/session_byspeaker_response.dart';
import '../../data/response_models/participant_response_model/speaker_part_in_participant/speaker_short_detail_responsemodel.dart';
import '../../repository/participants_repository/speaker_part_in_participant/session_byspeaker_viewmodel.dart';
import '../../view_model/participant_viewmodel/speaker_part_in_participant/speaker_full_detail_viewmodel.dart';
import '../seesion_details_view/session_detail_view.dart';
import 'package:cached_network_image/cached_network_image.dart';
class SpeakerDetailsScreen extends StatefulWidget {
  final SpeakerShortDetail speaker;
  const SpeakerDetailsScreen({super.key, required this.speaker});

  @override
  State<SpeakerDetailsScreen> createState() => _SpeakerDetailsScreenState();
}

class _SpeakerDetailsScreenState extends State<SpeakerDetailsScreen> {
  final SpeakerFullDetailViewModel speakerViewModel = Get.put(SpeakerFullDetailViewModel());
  final SessionBySpeakerViewModel sessionViewModel = Get.put(SessionBySpeakerViewModel());

  @override
  void initState() {
    super.initState();
    _fetchSpeakerFullDetails();
    _fetchSpeakerSessions();
  }

  void _fetchSpeakerFullDetails() {
    speakerViewModel.fetchSpeakerFullDetails(widget.speaker.id);
  }

  void _fetchSpeakerSessions() {
    sessionViewModel.fetchSessionsBySpeaker(widget.speaker.id);
  }

  // ==================== URL LAUNCHING METHODS ====================
  Future<void> _launchUrl(String url) async {
    try {
      final Uri uri = Uri.parse(url);
      if (!await launchUrl(uri)) {
        throw Exception('Could not launch $url');
      }
    } catch (e) {
      print('Error launching URL: $e');
    }
  }



// ==================== IMAGE BUILDER WITH CACHED NETWORK IMAGE ====================
  Widget _buildSpeakerImage(String? fileUrl) {
    // Debug print to see what URL we're receiving
    print('=== Building speaker image with URL: $fileUrl ===');

    if (fileUrl != null && fileUrl.isNotEmpty) {
      return ClipOval(
        child: CachedNetworkImage(
          imageUrl: fileUrl,
          width: 100,
          height: 100,
          fit: BoxFit.cover,
          placeholder: (context, url) => Container(
            width: 100,
            height: 100,
            decoration: BoxDecoration(
              color: Colors.grey[300],
              shape: BoxShape.circle,
            ),
            child: Center(
              child: CircularProgressIndicator(
                strokeWidth: 2,
                valueColor: AlwaysStoppedAnimation<Color>(AppColors.primaryColor),
              ),
            ),
          ),
          errorWidget: (context, url, error) {
            print('=== CachedNetworkImage error ===');
            print('URL: $url');
            print('Error: $error');
            return _buildDefaultAvatar();
          },
        ),
      );
    } else {
      print('=== No image URL provided, showing default avatar ===');
      return _buildDefaultAvatar();
    }
  }

  String _cleanImageUrl(String url) {
    try {
      // Basic URL cleaning
      String cleaned = url.trim();

      // Fix double extensions
      if (cleaned.contains('.png.jpg')) {
        cleaned = cleaned.replaceAll('.png.jpg', '.jpg');
      }
      if (cleaned.contains('.jpeg.jpg')) {
        cleaned = cleaned.replaceAll('.jpeg.jpg', '.jpg');
      }

      // Ensure it's a valid URL
      final uri = Uri.tryParse(cleaned);
      if (uri == null || !uri.isAbsolute) {
        print('=== Invalid URL: $cleaned ===');
        return url; // Return original if invalid
      }

      print('=== Using image URL: $cleaned ===');
      return cleaned;
    } catch (e) {
      print('=== URL cleaning error: $e ===');
      return url;
    }
  }

  Widget _buildDefaultAvatar() {
    return Container(
      width: 100,
      height: 100,
      decoration: BoxDecoration(
        color: Colors.grey[300],
        shape: BoxShape.circle,
      ),
      child: Icon(
        Icons.person,
        size: 40,
        color: Colors.grey[600],
      ),
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: CustomAppDrawer(),
      backgroundColor: AppColors.whiteColor,
      appBar: AppBar(
        backgroundColor: AppColors.whiteColor,
        title: const AppText(
          text: 'Speaker Details',
          fontSize: 18,
          fontWeight: FontWeight.w600,
          color: Colors.black,
        ),
        centerTitle: true,
      ),
      body: Obx(() {
        final speakerLoading = speakerViewModel.isLoading.value && speakerViewModel.speaker == null;
        final sessionLoading = sessionViewModel.isLoading.value && sessionViewModel.sessions.isEmpty;

        if (speakerLoading && sessionLoading) {
          return const Center(child: CircularProgressIndicator());
        }

        return SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ==================== SPEAKER PROFILE SECTION ====================
                _buildSpeakerProfileSection(),
                const SizedBox(height: 24),

                // ==================== AREAS OF EXPERTISE SECTION ====================
                if (_getExpertise().isNotEmpty)
                  _buildExpertiseSection(_getExpertise()),
                if (_getExpertise().isNotEmpty)
                  const SizedBox(height: 24),

                // ==================== SPEAKING SESSIONS SECTION ====================
                _buildSessionsSection(),
                const SizedBox(height: 24),

                // ==================== CONNECT & CONTACT SECTION ====================
                if (_hasSocialMedia())
                  _buildContactSection(),
                if (_hasSocialMedia())
                  const SizedBox(height: 32),
              ],
            ),
          ),
        );
      }),
    );
  }

  // ==================== HELPER METHODS FOR DATA EXTRACTION ====================
  List<String> _getExpertise() {
    final fullDetail = speakerViewModel.speaker;
    if (fullDetail != null) {
      return fullDetail.expertise;
    }
    return widget.speaker.expertise;
  }

  String _getBio() {
    final fullDetail = speakerViewModel.speaker;
    if (fullDetail != null) {
      return fullDetail.bio;
    }
    return widget.speaker.bio;
  }

  List<String> _getDesignations() {
    final fullDetail = speakerViewModel.speaker;
    if (fullDetail != null) {
      return fullDetail.designations;
    }
    return widget.speaker.designations;
  }

  String? _getCountry() {
    return speakerViewModel.speaker?.country;
  }

  bool _hasSocialMedia() {
    final fullDetail = speakerViewModel.speaker;
    if (fullDetail == null) return false;
    return fullDetail.website != null ||
        fullDetail.youtube != null ||
        fullDetail.facebook != null ||
        fullDetail.linkedin != null ||
        fullDetail.twitter != null;
  }

  // ==================== SPEAKER PROFILE SECTION ====================
  Widget _buildSpeakerProfileSection() {
    final designations = _getDesignations();
    final bio = _getBio();
    final country = _getCountry();
    final fullDetail = speakerViewModel.speaker;
    final imageUrl = fullDetail?.user.file ?? widget.speaker.user.file;

    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.containerGreyColor),
      ),
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Speaker Profile Image and Name
          Center(
            child: Column(
              children: [
                // CHANGED: Removed CircleAvatar wrapper, just use the image directly
                _buildSpeakerImage(imageUrl),
                const SizedBox(height: 16),
                AppText(
                  text: fullDetail?.user.name ?? widget.speaker.user.name,
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                  color: Colors.black,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 4),

                // Designations
                if (designations.isNotEmpty)
                  Column(
                    children: designations.map((designation) =>
                        AppText(
                          text: designation,
                          fontSize: 14,
                          color: AppColors.darkgrey,
                          textAlign: TextAlign.center,
                        ),
                    ).toList(),
                  ),

                // Country
                if (country != null) ...[
                  const SizedBox(height: 4),
                  AppText(
                    text: country,
                    fontSize: 14,
                    color: AppColors.darkgrey,
                    textAlign: TextAlign.center,
                  ),
                ],
              ],
            ),
          ),

          const SizedBox(height: 24),

          // Biography Section
          const AppText(
            text: 'Biography',
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Colors.black,
          ),
          const SizedBox(height: 12),
          AppText(
            text: bio.isNotEmpty ? bio : 'No biography available',
            fontSize: 14,
            color: AppColors.darkgrey,
          ),
        ],
      ),
    );
  }

  // ==================== EXPERTISE SECTION ====================
  Widget _buildExpertiseSection(List<String> expertise) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.containerGreyColor),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const AppText(
            text: 'Areas of Expertise',
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: Colors.black,
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: expertise.map((expertise) =>
                _buildExpertiseChip(expertise, _getRandomChipColor()),
            ).toList(),
          ),
        ],
      ),
    );
  }

  // ==================== SESSIONS SECTION ====================
  Widget _buildSessionsSection() {
    return Obx(() {
      final sessions = sessionViewModel.sessions;
      final isLoading = sessionViewModel.isLoading.value;
      final error = sessionViewModel.errorMessage.value;

      if (isLoading) {
        return const Center(child: CircularProgressIndicator());
      }

      if (error.isNotEmpty) {
        return Column(
          children: [
            AppText(
              text: 'Error loading sessions',
              fontSize: 16,
              color: Colors.red,
            ),
            const SizedBox(height: 16),
            CustomButton(
              text: 'Retry',
              onPressed: _fetchSpeakerSessions,
              backgroundColor: AppColors.primaryColor,
              textColor: AppColors.whiteColor,
            ),
          ],
        );
      }

      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              AppText(
                text: 'Speaking Sessions (${sessions.length})',
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: Colors.black,
              ),
              const Icon(
                Icons.keyboard_arrow_up,
                color: AppColors.darkgrey,
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Dynamic Session Cards
          if (sessions.isEmpty)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.whiteColor,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.mediumGreyColor),
              ),
              child: const Center(
                child: AppText(
                  text: 'No sessions available',
                  fontSize: 14,
                  color: AppColors.darkgrey,
                ),
              ),
            )
          else
            Column(
              children: sessions.map((session) =>
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: _buildSessionCard(session),
                  ),
              ).toList(),
            ),
        ],
      );
    });
  }

  // ==================== CONTACT SECTION ====================
  Widget _buildContactSection() {
    final speaker = speakerViewModel.speaker;
    if (speaker == null) return const SizedBox();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const AppText(
          text: 'Connect & Contact',
          fontSize: 18,
          fontWeight: FontWeight.w600,
          color: Colors.black,
        ),
        const SizedBox(height: 16),

        // LinkedIn
        if (speaker.linkedin != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _buildContactOption(
              const AssetImage('assets/icons/linkedin.png'),
              'LinkedIn',
              onTap: () => _launchUrl(speaker.linkedin!),
            ),
          ),

        // Facebook
        if (speaker.facebook != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _buildContactOption(
              const AssetImage('assets/Facebook.png'),
              'Facebook',
              onTap: () => _launchUrl(speaker.facebook!),
            ),
          ),

        // Website
        if (speaker.website != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _buildContactOption(
              const AssetImage('assets/icons/website.png'),
              'Website',
              onTap: () => _launchUrl(speaker.website!),
            ),
          ),

        // Twitter
        if (speaker.twitter != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _buildContactOption(
              const AssetImage('assets/icons/twitter.png'),
              'Twitter',
              onTap: () => _launchUrl(speaker.twitter!),
            ),
          ),

        // YouTube
        if (speaker.youtube != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _buildContactOption(
              const AssetImage('assets/icons/youtube.png'),
              'YouTube',
              onTap: () => _launchUrl(speaker.youtube!),
            ),
          ),
      ],
    );
  }

  // ==================== HELPER WIDGETS ====================
  Widget _buildExpertiseChip(String text, Color backgroundColor) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(16),
      ),
      child: AppText(
        text: text,
        fontSize: 12,
        fontWeight: FontWeight.w500,
        color: AppColors.primaryColor,
      ),
    );
  }
  Widget _buildSessionCard(SessionBySpeaker session) {
    final sessionTypeColor = _getSessionTypeColor(session.category);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.whiteColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.mediumGreyColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: AppText(
                  text: session.title,
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Colors.black,
                ),
              ),
              Icon(
                Icons.bookmark_border,
                color: AppColors.primaryColor,
                size: 20,
              ),
            ],
          ),
          const SizedBox(height: 8),

          // Session Description
          if (session.description.isNotEmpty)
            Column(
              children: [
                AppText(
                  text: session.description,
                  fontSize: 12,
                  color: AppColors.darkgrey,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 8),
              ],
            ),

          // Session Details Row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Time
              Row(
                children: [
                  Icon(Icons.access_time, size: 12, color: AppColors.darkgrey),
                  const SizedBox(width: 4),
                  Text( // Use regular Text widget for small font sizes
                    session.formattedTime,
                    style: TextStyle(
                      fontSize: 10,
                      color: AppColors.darkgrey,
                    ),
                  ),
                ],
              ),

              // Duration
              Row(
                children: [
                  Text( // Use regular Text widget for small font sizes
                    'Duration: ',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                      color: Colors.black,
                    ),
                  ),
                  Text( // Use regular Text widget for small font sizes
                    session.duration,
                    style: TextStyle(
                      fontSize: 10,
                      color: AppColors.darkgrey,
                    ),
                  ),
                ],
              ),

              // Room
              Row(
                children: [
                  Text( // Use regular Text widget for small font sizes
                    'Room: ',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                      color: Colors.black,
                    ),
                  ),
                  Text( // Use regular Text widget for small font sizes
                    session.location,
                    style: TextStyle(
                      fontSize: 10,
                      color: AppColors.darkgrey,
                    ),
                  ),
                ],
              ),
            ],
          ),

          const SizedBox(height: 8),

          // Session Type and Capacity
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Session Type
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: sessionTypeColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text( // Use regular Text widget for small font sizes
                  session.category,
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w500,
                    color: sessionTypeColor,
                  ),
                ),
              ),

              // Capacity
              Text( // Use regular Text widget for small font sizes
                'Capacity: ${session.capacity}',
                style: TextStyle(
                  fontSize: 10,
                  color: AppColors.darkgrey,
                ),
              ),

              // Registration Required
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: session.registrationRequired ? Colors.orange.withOpacity(0.1) : Colors.green.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text( // Use regular Text widget for small font sizes
                  session.registrationRequired ? 'Registration Required' : 'Open',
                  style: TextStyle(
                    fontSize: 10, // Changed from 8 to 10
                    fontWeight: FontWeight.w500,
                    color: session.registrationRequired ? Colors.orange : Colors.green,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: 12),
          CustomButton(
            text: 'View Session Details',
            onPressed: () {
              _navigateToSessionDetails(session.id);
            },
            backgroundColor: AppColors.primaryColor,
            height: 40,
          ),
        ],
      ),
    );
  }

  Widget _buildContactOption(AssetImage image, String title, {VoidCallback? onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.whiteColor,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.mediumGreyColor),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image(
              image: image,
              width: 30,
              height: 30,
            ),
            const SizedBox(width: 12),
            AppText(
              text: title,
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: Colors.black,
            ),
          ],
        ),
      ),
    );
  }

  // ==================== HELPER METHODS ====================
  Color _getRandomChipColor() {
    final colors = [AppColors.lightred, AppColors.lightPurpleColor];
    return colors[DateTime.now().millisecond % colors.length];
  }

  Color _getSessionTypeColor(String category) {
    switch (category.toLowerCase()) {
      case 'keynote':
        return Colors.blue;
      case 'workshop':
        return Colors.green;
      case 'panel':
        return Colors.orange;
      case 'breakout':
        return Colors.purple;
      default:
        return AppColors.primaryColor;
    }
  }

  void _navigateToSessionDetails(int sessionId) {
    print('=== Navigating to session details for ID: $sessionId ===');
    // Navigate to session details screen
     Get.to(() => SessionDetailsScreen(sessionId: sessionId));
  }
}