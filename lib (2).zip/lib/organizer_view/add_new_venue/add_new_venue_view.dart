import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:al_sharq_conference/app_colors/app_colors.dart';
import 'package:al_sharq_conference/custom_widgets/app_text.dart';
import 'package:al_sharq_conference/custom_widgets/custom_button.dart';
import 'package:al_sharq_conference/custom_widgets/custom_text_field.dart';

import '../../view_model/organizer_viewmodels/organizer_create_event_venue_viewmodel.dart';
import '../../view_model/organizer_viewmodels/organizer_showlist_exhibitors_viewmodel.dart';
import '../../view_model/organizer_viewmodels/organizer_showlist_sponsors_viewmodel.dart';

class AddNewVenueScreen extends StatefulWidget {
  final int? eventId;

  const AddNewVenueScreen({super.key, this.eventId});

  @override
  _AddNewVenueScreenState createState() => _AddNewVenueScreenState();
}

class _AddNewVenueScreenState extends State<AddNewVenueScreen> {
  final TextEditingController titleController = TextEditingController();
  final TextEditingController locationController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();
  final TextEditingController googleMapLinkController = TextEditingController();
  final TextEditingController startTimeController = TextEditingController();
  final TextEditingController endTimeController = TextEditingController();

  final OrganizerCreateEventVenueViewModel _createViewModel = Get.put(OrganizerCreateEventVenueViewModel());
  final OrganizerShowListSponsorsViewModel _sponsorsViewModel = Get.put(OrganizerShowListSponsorsViewModel());
  final OrganizerShowListExhibitorsViewModel _exhibitorsViewModel = Get.put(OrganizerShowListExhibitorsViewModel());

  bool isVisibleToParticipants = false;
  List<File> selectedImages = [];
  List<int> selectedSponsors = [];
  List<int> selectedExhibitors = [];

  @override
  void initState() {
    super.initState();
    _loadSponsorsAndExhibitors();

    if (widget.eventId != null) {
      _loadEventData();
    }
  }

  void _loadSponsorsAndExhibitors() {
    _sponsorsViewModel.getSponsorsList();
    _exhibitorsViewModel.getExhibitorsList();
  }

  void _loadEventData() {
    _createViewModel.getEvent(widget.eventId!).then((_) {
      final event = _createViewModel.eventData.value;
      titleController.text = event.title;
      locationController.text = event.location;
      descriptionController.text = event.description;
      googleMapLinkController.text = event.googleMapLink;
      isVisibleToParticipants = event.mapstatus;

      if (event.startTime != null) {
        startTimeController.text = event.startTime!;
      }
      if (event.endTime != null) {
        endTimeController.text = event.endTime!;
      }

      selectedSponsors = event.sponsors.map((sponsor) => sponsor.id).toList();
      selectedExhibitors = event.exhibitors.map((exhibitor) => exhibitor.id).toList();

      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundColor,
      appBar: AppBar(
        backgroundColor: AppColors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: AppColors.darkgrey),
          onPressed: () => Get.back(),
        ),
        title: AppText(
          text: widget.eventId != null ? 'Edit Venue' : 'Add New Venue',
          fontSize: 18,
          fontWeight: FontWeight.w600,
          color: AppColors.darkgrey,
        ),
        centerTitle: true,
      ),
      body: Obx(() {
        return SingleChildScrollView(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Title Field
              AppText(
                text: 'Title*',
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: AppColors.darkgrey,
              ),
              SizedBox(height: 8),
              CustomTextField(
                controller: titleController,
                hintText: 'Enter a clear title',
              ),

              SizedBox(height: 24),

              // Location Field
              AppText(
                text: 'Location*',
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: AppColors.darkgrey,
              ),
              SizedBox(height: 8),
              CustomTextField(
                controller: locationController,
                hintText: 'New York, USA',
              ),

              SizedBox(height: 24),

              // Google Maps Link Field
              AppText(
                text: 'Google Maps Link*',
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: AppColors.darkgrey,
              ),
              SizedBox(height: 8),
              CustomTextField(
                controller: googleMapLinkController,
                hintText: 'https://maps.google.com/?q=123+Main+St',
              ),

              SizedBox(height: 24),

              // Start Time Field
              AppText(
                text: 'Start Time',
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: AppColors.darkgrey,
              ),
              SizedBox(height: 8),
              CustomTextField(
                controller: startTimeController,
                hintText: '2025-10-08T14:00:00Z',
              ),

              SizedBox(height: 24),

              // End Time Field
              AppText(
                text: 'End Time',
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: AppColors.darkgrey,
              ),
              SizedBox(height: 8),
              CustomTextField(
                controller: endTimeController,
                hintText: '2025-10-08T16:00:00Z',
              ),

              SizedBox(height: 24),

              // Description Field
              AppText(
                text: 'Description',
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: AppColors.darkgrey,
              ),
              SizedBox(height: 8),
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey[50],
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.grey[300]!),
                ),
                child: TextField(
                  controller: descriptionController,
                  maxLines: 4,
                  style: TextStyle(
                    fontSize: 16,
                    color: AppColors.darkgrey,
                  ),
                  decoration: InputDecoration(
                    hintText: 'Describe your topic in detail',
                    hintStyle: TextStyle(
                      fontSize: 16,
                      color: AppColors.lightGrey,
                    ),
                    border: InputBorder.none,
                  ),
                ),
              ),

              SizedBox(height: 24),

              // Sponsors Selection
              _buildSponsorsSelection(),

              SizedBox(height: 24),

              // Exhibitors Selection
              _buildExhibitorsSelection(),

              SizedBox(height: 24),

              // Visibility Toggle
              AppText(
                text: 'Visibility*',
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: AppColors.darkgrey,
              ),
              SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  AppText(
                    text: 'Map Visible to Participants',
                    fontSize: 14,
                    color: AppColors.darkgrey,
                  ),
                  Switch(
                    value: isVisibleToParticipants,
                    onChanged: (value) {
                      setState(() {
                        isVisibleToParticipants = value;
                      });
                    },
                    activeColor: AppColors.primaryColor,
                  ),
                ],
              ),

              SizedBox(height: 40),

              // Add/Update Button
              CustomButton(
                text: widget.eventId != null ? 'Update' : 'Add',
                onPressed: _createViewModel.isLoading.value ? null : _saveVenue,
                backgroundColor: AppColors.primaryColor,
              ),

              SizedBox(height: 20),
            ],
          ),
        );
      }),
    );
  }

  Widget _buildSponsorsSelection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        AppText(
          text: 'Select Sponsors',
          fontSize: 16,
          fontWeight: FontWeight.w500,
          color: AppColors.darkgrey,
        ),
        SizedBox(height: 8),
        Container(
          padding: EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.grey[50],
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.grey[300]!),
          ),
          child: Obx(() {
            if (_sponsorsViewModel.isLoading.value) {
              return Center(child: CircularProgressIndicator());
            }

            return Column(
              children: _sponsorsViewModel.sponsorsList.map((sponsor) {
                return CheckboxListTile(
                  title: AppText(
                    text: '${sponsor.name} (${sponsor.email})',
                    fontSize: 14,
                    color: AppColors.darkgrey,
                  ),
                  value: selectedSponsors.contains(sponsor.id),
                  onChanged: (bool? value) {
                    setState(() {
                      if (value == true) {
                        selectedSponsors.add(sponsor.id);
                      } else {
                        selectedSponsors.remove(sponsor.id);
                      }
                    });
                  },
                );
              }).toList(),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildExhibitorsSelection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        AppText(
          text: 'Select Exhibitors',
          fontSize: 16,
          fontWeight: FontWeight.w500,
          color: AppColors.darkgrey,
        ),
        SizedBox(height: 8),
        Container(
          padding: EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.grey[50],
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.grey[300]!),
          ),
          child: Obx(() {
            if (_exhibitorsViewModel.isLoading.value) {
              return Center(child: CircularProgressIndicator());
            }

            return Column(
              children: _exhibitorsViewModel.exhibitorsList.map((exhibitor) {
                return CheckboxListTile(
                  title: AppText(
                    text: '${exhibitor.name} (${exhibitor.email})',
                    fontSize: 14,
                    color: AppColors.darkgrey,
                  ),
                  value: selectedExhibitors.contains(exhibitor.id),
                  onChanged: (bool? value) {
                    setState(() {
                      if (value == true) {
                        selectedExhibitors.add(exhibitor.id);
                      } else {
                        selectedExhibitors.remove(exhibitor.id);
                      }
                    });
                  },
                );
              }).toList(),
            );
          }),
        ),
      ],
    );
  }

  void _saveVenue() {
    if (titleController.text.isEmpty) {
      Get.snackbar('Error', 'Please enter a title',
          backgroundColor: Colors.red.withOpacity(0.1),
          colorText: Colors.red);
      return;
    }

    if (locationController.text.isEmpty) {
      Get.snackbar('Error', 'Please enter a location',
          backgroundColor: Colors.red.withOpacity(0.1),
          colorText: Colors.red);
      return;
    }

    if (googleMapLinkController.text.isEmpty) {
      Get.snackbar('Error', 'Please enter a Google Maps link',
          backgroundColor: Colors.red.withOpacity(0.1),
          colorText: Colors.red);
      return;
    }

    final eventData = {
      "title": titleController.text,
      "description": descriptionController.text,
      "location": locationController.text,
      "googleMapLink": googleMapLinkController.text,
      "mapstatus": isVisibleToParticipants,
      "sponsors": selectedSponsors.map((id) => {"id": id}).toList(),
      "exhibitors": selectedExhibitors.map((id) => {"id": id}).toList(),
    };

    // Add optional fields if they are not empty
    if (startTimeController.text.isNotEmpty) {
      eventData["startTime"] = startTimeController.text;
    }
    if (endTimeController.text.isNotEmpty) {
      eventData["endTime"] = endTimeController.text;
    }

    if (widget.eventId != null) {
      // Update existing event
      _createViewModel.updateEvent(widget.eventId!, eventData).then((success) {
        if (success) {
          Get.back();
        }
      });
    } else {
      // Create new event
      _createViewModel.createEvent(eventData).then((success) {
        if (success) {
          Get.back();
        }
      });
    }
  }

  void _pickImages() async {
    final ImagePicker picker = ImagePicker();
    final List<XFile>? images = await picker.pickMultiImage();

    if (images != null) {
      setState(() {
        selectedImages = images.map((image) => File(image.path)).toList();
      });
    }
  }

  @override
  void dispose() {
    titleController.dispose();
    locationController.dispose();
    descriptionController.dispose();
    googleMapLinkController.dispose();
    startTimeController.dispose();
    endTimeController.dispose();
    super.dispose();
  }
}




// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:image_picker/image_picker.dart';
// import 'dart:io';
//
// import '../../app_colors/app_colors.dart';
// import '../../custom_widgets/app_text.dart';
// import '../../custom_widgets/custom_button.dart';
// import '../../custom_widgets/custom_text_field.dart';
//
//
//
// class AddNewVenueScreen extends StatefulWidget {
//   @override
//   _AddNewVenueScreenState createState() => _AddNewVenueScreenState();
// }
//
// class _AddNewVenueScreenState extends State<AddNewVenueScreen> {
//   final TextEditingController titleController = TextEditingController();
//   final TextEditingController locationController = TextEditingController();
//   final TextEditingController descriptionController = TextEditingController();
//
//   String selectedEvent = 'Select an event';
//   bool isVisibleToParticipants = false;
//   List<File> selectedImages = [];
//
//   final List<String> events = [
//     'Select an event',
//     'Tech Conference 2024',
//     'Business Summit',
//     'Innovation Workshop',
//     'Startup Meetup',
//   ];
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: AppColors.backgroundColor,
//       appBar: AppBar(
//         backgroundColor: AppColors.white,
//         elevation: 0,
//         leading: IconButton(
//           icon: Icon(Icons.arrow_back, color: AppColors.darkgrey),
//           onPressed: () => Get.back(),
//         ),
//         title: AppText(
//           text: 'Add New Venue',
//           fontSize: 18,
//           fontWeight: FontWeight.w600,
//           color: AppColors.darkgrey,
//         ),
//         centerTitle: true,
//       ),
//       body: SingleChildScrollView(
//         padding: EdgeInsets.all(16),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             // Title Field
//             AppText(
//               text: 'Title*',
//               fontSize: 16,
//               fontWeight: FontWeight.w500,
//               color: AppColors.darkgrey,
//             ),
//             SizedBox(height: 8),
//             CustomTextField(
//               controller: titleController,
//               hintText: 'Enter a clear title',
//             ),
//
//             SizedBox(height: 24),
//
//
//             SizedBox(height: 8),
//             Container(
//               padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
//               decoration: BoxDecoration(
//                 color: Colors.grey[50],
//                 borderRadius: BorderRadius.circular(8),
//                 border: Border.all(color: Colors.grey[300]!),
//               ),
//               child: DropdownButtonHideUnderline(
//                 child: DropdownButton<String>(
//                   value: selectedEvent,
//                   isExpanded: true,
//                   icon: Icon(Icons.keyboard_arrow_down, color: AppColors.darkgrey),
//                   items: events.map((String event) {
//                     return DropdownMenuItem<String>(
//                       value: event,
//                       child: AppText(
//                         text: event,
//                         fontSize: 16,
//                         color: event == 'Select an event' ? AppColors.lightGrey : AppColors.darkgrey,
//                       ),
//                     );
//                   }).toList(),
//                   onChanged: (String? newValue) {
//                     setState(() {
//                       selectedEvent = newValue!;
//                     });
//                   },
//                 ),
//               ),
//             ),
//
//             SizedBox(height: 24),
//
//             // Location Field
//             AppText(
//               text: 'Location*',
//               fontSize: 16,
//               fontWeight: FontWeight.w500,
//               color: AppColors.darkgrey,
//             ),
//             SizedBox(height: 8),
//             CustomTextField(
//               controller: locationController,
//               hintText: 'New York, USA',
//             ),
//
//             SizedBox(height: 24),
//
//             // Description Field
//             AppText(
//               text: 'Description',
//               fontSize: 16,
//               fontWeight: FontWeight.w500,
//               color: AppColors.darkgrey,
//             ),
//             SizedBox(height: 8),
//             Container(
//               padding: EdgeInsets.all(16),
//               decoration: BoxDecoration(
//                 color: Colors.grey[50],
//                 borderRadius: BorderRadius.circular(8),
//                 border: Border.all(color: Colors.grey[300]!),
//               ),
//               child: TextField(
//                 controller: descriptionController,
//                 maxLines: 4,
//                 style: TextStyle(
//                   fontSize: 16,
//                   color: AppColors.darkgrey,
//                 ),
//                 decoration: InputDecoration(
//                   hintText: 'Describe your topic in detail',
//                   hintStyle: TextStyle(
//                     fontSize: 16,
//                     color: AppColors.lightGrey,
//                   ),
//                   border: InputBorder.none,
//                 ),
//               ),
//             ),
//
//             SizedBox(height: 24),
//
//             // Upload Media Section
//             AppText(
//               text: 'Upload Media',
//               fontSize: 16,
//               fontWeight: FontWeight.w500,
//               color: AppColors.darkgrey,
//             ),
//             SizedBox(height: 8),
//
//
//             SizedBox(height: 24),
//
//             // Visibility Toggle
//             AppText(
//               text: 'Visibility*',
//               fontSize: 16,
//               fontWeight: FontWeight.w500,
//               color: AppColors.darkgrey,
//             ),
//             SizedBox(height: 8),
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 AppText(
//                   text: 'Map Visible to Participants',
//                   fontSize: 14,
//                   color: AppColors.darkgrey,
//                 ),
//                 Switch(
//                   value: isVisibleToParticipants,
//                   onChanged: (value) {
//                     setState(() {
//                       isVisibleToParticipants = value;
//                     });
//                   },
//                   activeColor: AppColors.primaryColor,
//                 ),
//               ],
//             ),
//
//             SizedBox(height: 40),
//
//             // Add Button
//             CustomButton(
//               text: 'Add',
//               onPressed: _addVenue,
//               backgroundColor: AppColors.primaryColor,
//             ),
//
//             SizedBox(height: 20),
//           ],
//         ),
//       ),
//     );
//   }
//
//   void _pickImages() async {
//     final ImagePicker picker = ImagePicker();
//     final List<XFile>? images = await picker.pickMultiImage();
//
//     if (images != null) {
//       setState(() {
//         selectedImages = images.map((image) => File(image.path)).toList();
//       });
//     }
//   }
//
//   void _addVenue() {
//     if (titleController.text.isEmpty) {
//       Get.snackbar('Error', 'Please enter a title',
//           backgroundColor: AppColors.errorColor.withOpacity(0.1),
//           colorText: AppColors.errorColor);
//       return;
//     }
//
//     if (selectedEvent == 'Select an event') {
//       Get.snackbar('Error', 'Please select an event',
//           backgroundColor: AppColors.errorColor.withOpacity(0.1),
//           colorText: AppColors.errorColor);
//       return;
//     }
//
//     if (locationController.text.isEmpty) {
//       Get.snackbar('Error', 'Please enter a location',
//           backgroundColor: AppColors.errorColor.withOpacity(0.1),
//           colorText: AppColors.errorColor);
//       return;
//     }
//
//     // Show success message
//     Get.snackbar('Success', 'Venue added successfully!',
//         backgroundColor: AppColors.successColor.withOpacity(0.1),
//         colorText: AppColors.successColor);
//
//     // Navigate back
//     Get.back();
//   }
//
//   @override
//   void dispose() {
//     titleController.dispose();
//     locationController.dispose();
//     descriptionController.dispose();
//     super.dispose();
//   }
// }