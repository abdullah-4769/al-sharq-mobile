import 'package:get/get.dart';
import 'package:al_sharq_conference/repository/organizer_repo/organizervenueshowrepo.dart';

import '../../data/response_models/organizer_response_models/organizer_venue_show_model.dart';

class OrganizerVenueShowViewModel extends GetxController {
  final _repo = OrganizerVenueShowRepo();

  var isLoading = false.obs;
  var error = ''.obs;
  var venueData = OrganizerVenueShowModel(
    totalSessions: 0,
    liveSessions: 0,
    scheduledSessions: 0,
    events: [],
  ).obs;

  Future<void> getVenueSummary() async {
    try {
      isLoading.value = true;
      error.value = '';

      final data = await _repo.getVenueSummary();
      venueData.value = data;
    } catch (e) {
      error.value = e.toString();
      print('Error in getVenueSummary: $e');
    } finally {
      isLoading.value = false;
    }
  }
}