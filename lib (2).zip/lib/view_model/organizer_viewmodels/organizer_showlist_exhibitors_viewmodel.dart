import 'package:get/get.dart';
import '../../data/response_models/organizer_response_models/organizer_showlist_exhibitors_model.dart';
import '../../repository/organizer_repo/organizer_showlist_exhibitors_repo.dart';

class OrganizerShowListExhibitorsViewModel extends GetxController {
  final _repo = OrganizerShowListExhibitorsRepo();

  var isLoading = false.obs;
  var error = ''.obs;
  var exhibitorsList = <OrganizerShowListExhibitorsModel>[].obs;

  Future<void> getExhibitorsList() async {
    try {
      isLoading.value = true;
      error.value = '';

      final exhibitors = await _repo.getExhibitorsList();
      exhibitorsList.value = exhibitors;
    } catch (e) {
      error.value = e.toString();
    } finally {
      isLoading.value = false;
    }
  }
}