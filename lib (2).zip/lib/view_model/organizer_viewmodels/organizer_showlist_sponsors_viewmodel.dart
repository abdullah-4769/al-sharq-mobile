import 'package:get/get.dart';
import '../../data/response_models/organizer_response_models/organizer_show_list_sponsors_model.dart';
import '../../repository/organizer_repo/organizer_show_list_sponsors_repo.dart';

class OrganizerShowListSponsorsViewModel extends GetxController {
  final _repo = OrganizerShowListSponsorsRepo();

  var isLoading = false.obs;
  var error = ''.obs;
  var sponsorsList = <OrganizerShowListSponsorsModel>[].obs;

  Future<void> getSponsorsList() async {
    try {
      isLoading.value = true;
      error.value = '';

      final sponsors = await _repo.getSponsorsList();
      sponsorsList.value = sponsors;
    } catch (e) {
      error.value = e.toString();
    } finally {
      isLoading.value = false;
    }
  }
}