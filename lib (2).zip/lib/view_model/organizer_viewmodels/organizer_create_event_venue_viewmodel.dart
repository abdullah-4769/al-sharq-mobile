import 'package:get/get.dart';
import '../../data/request_models/organizer/organizer_create_event_venue_model.dart';
import '../../repository/organizer_repo/organizer_create_event_venue_repo.dart';
import 'package:flutter/material.dart';
class OrganizerCreateEventVenueViewModel extends GetxController {
  final _repo = OrganizerCreateEventVenueRepo();

  var isLoading = false.obs;
  var error = ''.obs;
  var success = false.obs;
  var eventData = OrganizerCreateEventVenueModel(
    id: 0,
    title: '',
    description: '',
    location: '',
    googleMapLink: '',
    joinToken: '',
    mapstatus: false,
    sponsors: [],
    exhibitors: [],
  ).obs;

  Future<bool> createEvent(Map<String, dynamic> data) async {
    try {
      isLoading.value = true;
      error.value = '';
      success.value = false;

      final response = await _repo.createEvent(data);
      eventData.value = response;
      success.value = true;

      Get.snackbar(
        'Success',
        'Event created successfully',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green,
        colorText: Colors.white,
      );
      return true;
    } catch (e) {
      error.value = e.toString();
      Get.snackbar(
        'Error',
        'Failed to create event: ${e.toString()}',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
      return false;
    } finally {
      isLoading.value = false;
    }
  }

  Future<bool> updateEvent(int eventId, Map<String, dynamic> data) async {
    try {
      isLoading.value = true;
      error.value = '';
      success.value = false;

      final response = await _repo.updateEvent(eventId, data);
      eventData.value = response;
      success.value = true;

      Get.snackbar(
        'Success',
        'Event updated successfully',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green,
        colorText: Colors.white,
      );
      return true;
    } catch (e) {
      error.value = e.toString();
      Get.snackbar(
        'Error',
        'Failed to update event: ${e.toString()}',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
      return false;
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> getEvent(int eventId) async {
    try {
      isLoading.value = true;
      error.value = '';

      final response = await _repo.getEvent(eventId);
      eventData.value = response;
    } catch (e) {
      error.value = e.toString();
    } finally {
      isLoading.value = false;
    }
  }
}