import 'package:get/get.dart';
import '../../repository/organizer_repo/organizer_event_delete_repo.dart';
import 'package:flutter/material.dart';
class OrganizerEventDeleteViewModel extends GetxController {
  final _repo = OrganizerEventDeleteRepo();

  var isLoading = false.obs;
  var error = ''.obs;
  var success = false.obs;

  Future<bool> deleteEvent(int eventId) async {
    try {
      isLoading.value = true;
      error.value = '';
      success.value = false;

      final response = await _repo.deleteEvent(eventId);
      success.value = response.success;

      if (response.success) {
        Get.snackbar(
          'Success',
          response.message,
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.green,
          colorText: Colors.white,
        );
        return true;
      } else {
        error.value = response.message;
        Get.snackbar(
          'Error',
          response.message,
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.red,
          colorText: Colors.white,
        );
        return false;
      }
    } catch (e) {
      error.value = e.toString();
      Get.snackbar(
        'Error',
        'Failed to delete event: ${e.toString()}',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
      return false;
    } finally {
      isLoading.value = false;
    }
  }
}