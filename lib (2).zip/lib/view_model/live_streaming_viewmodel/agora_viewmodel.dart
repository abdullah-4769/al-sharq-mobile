import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../services/live_streaming_services/agora_services.dart';

class AgoraViewModel extends GetxController {
  final AgoraService _agoraService = Get.find<AgoraService>();

  final RxBool isLoading = false.obs;
  final RxString errorMessage = ''.obs;
  final RxString currentChannel = ''.obs;
  final RxString userDisplayName = ''.obs;
  final RxString userRole = 'audience'.obs;

  // Chat
  final RxList<ChatMessage> messages = <ChatMessage>[].obs;
  final TextEditingController chatController = TextEditingController();
  final ScrollController scrollController = ScrollController();
  final RxInt unreadCount = 0.obs;
  final RxBool showChat = false.obs;

  // Participants
  final RxBool showParticipants = false.obs;
  final RxString viewMode = 'grid'.obs;
  final Rx<ParticipantInfo?> selectedSpeaker = Rx<ParticipantInfo?>(null);

  // REACTIVE PARTICIPANTS LIST
  final RxList<ParticipantInfo> participantsRx = <ParticipantInfo>[].obs;

  // CRITICAL: Force UI rebuild trigger
  final RxInt renderTrigger = 0.obs;

  AgoraService get agoraService => _agoraService;
  bool get isJoined => _agoraService.isJoined.value;
  bool get isHost => userRole.value == 'host';


  // Add these methods to your AgoraViewModel

  Future<void> muteUserVideo(int uid) async {
    try {
      if (!isHost) return;

      final participant = participants.firstWhere((p) => p.uid == uid);

      if (uid == _agoraService.localUserId) {
        // Mute self video
        await _agoraService.toggleVideo();
        addSystemMessage('Host turned off their video');
      } else {
        // Mute remote user video
        await _agoraService.engine.muteRemoteVideoStream(uid: uid, mute: true);
        addSystemMessage('Host turned off video for ${participant.name}');
        sendSystemMessage('Host turned off video for ${participant.name}');
      }

      refreshParticipants();
    } catch (e) {
      debugPrint('=== Error muting user video: $e ===');
    }
  }

  Future<void> unmuteUserVideo(int uid) async {
    try {
      if (!isHost) return;

      final participant = participants.firstWhere((p) => p.uid == uid);

      if (uid == _agoraService.localUserId) {
        // Unmute self video
        await _agoraService.toggleVideo();
        addSystemMessage('Host turned on their video');
      } else {
        // Unmute remote user video
        await _agoraService.engine.muteRemoteVideoStream(uid: uid, mute: false);
        addSystemMessage('Host turned on video for ${participant.name}');
        sendSystemMessage('Host turned on video for ${participant.name}');
      }

      refreshParticipants();
    } catch (e) {
      debugPrint('=== Error unmuting user video: $e ===');
    }
  }
  @override
  void onInit() {
    super.onInit();
    debugPrint('=== AgoraViewModel initialized ===');

    // Auto-refresh participants on any change
    ever(_agoraService.isJoined, (_) {
      refreshParticipants();
      renderTrigger.value++;
    });
    ever(_agoraService.isAudioEnabled, (_) => refreshParticipants());
    ever(_agoraService.isVideoEnabled, (_) {
      refreshParticipants();
      renderTrigger.value++;
    });
    ever(_agoraService.isScreenSharing, (_) => refreshParticipants());
    ever(_agoraService.remoteUsers, (_) {
      refreshParticipants();
      renderTrigger.value++;
    });
    ever(_agoraService.userStates, (_) => refreshParticipants());
  }
// In AgoraViewModel - Add these enhanced host control methods

// Enhanced toggleAudio that works for both host and audience
  Future<void> toggleAudio() async {
    try {
      if (!isJoined) return;

      if (isHost) {
        // Host can toggle their own audio
        final newState = !_agoraService.isAudioEnabled.value;
        await _agoraService.toggleAudio();
        addSystemMessage('${userDisplayName.value} ${newState ? "unmuted" : "muted"} mic');
      } else {
        // Audience can request to unmute themselves
        final newState = !_agoraService.isAudioEnabled.value;
        await _agoraService.toggleAudio();

        if (newState) {
          addSystemMessage('${userDisplayName.value} unmuted their mic');
          // Show notification to host
          if (Get.isRegistered<AgoraViewModel>()) {
            // This will notify the host that someone unmuted
            debugPrint('=== Audience member ${userDisplayName.value} unmuted ===');
          }
        } else {
          addSystemMessage('${userDisplayName.value} muted their mic');
        }
      }

      refreshParticipants();
      renderTrigger.value++;
    } catch (e) {
      debugPrint('=== Error toggling audio: $e ===');
    }
  }

// Enhanced host controls for remote users
  Future<void> muteUserAudio(int uid) async {
    try {
      if (!isHost) {
        Get.snackbar(
          'Permission Denied',
          'Only host can mute users',
          backgroundColor: Colors.orange.shade700,
          colorText: Colors.white,
        );
        return;
      }

      final participant = participants.firstWhere((p) => p.uid == uid);

      if (uid == _agoraService.localUserId) {
        // Mute self
        await _agoraService.toggleAudio();
        addSystemMessage('Host muted themselves');
      } else {
        // Mute remote user
        await _agoraService.engine.muteRemoteAudioStream(uid: uid, mute: true);
        addSystemMessage('Host muted ${participant.name}');

        // Send system message to everyone
        sendSystemMessage('Host muted ${participant.name}');
      }

      refreshParticipants();
    } catch (e) {
      debugPrint('=== Error muting user audio: $e ===');
      Get.snackbar(
        'Error',
        'Failed to mute user: $e',
        backgroundColor: Colors.red.shade700,
        colorText: Colors.white,
      );
    }
  }

  Future<void> unmuteUserAudio(int uid) async {
    try {
      if (!isHost) {
        Get.snackbar(
          'Permission Denied',
          'Only host can unmute users',
          backgroundColor: Colors.orange.shade700,
          colorText: Colors.white,
        );
        return;
      }

      final participant = participants.firstWhere((p) => p.uid == uid);

      if (uid == _agoraService.localUserId) {
        // Unmute self
        await _agoraService.toggleAudio();
        addSystemMessage('Host unmuted themselves');
      } else {
        // Unmute remote user
        await _agoraService.engine.muteRemoteAudioStream(uid: uid, mute: false);
        addSystemMessage('Host unmuted ${participant.name}');

        // Send system message to everyone
        sendSystemMessage('Host unmuted ${participant.name}');
      }

      refreshParticipants();
    } catch (e) {
      debugPrint('=== Error unmuting user audio: $e ===');
      Get.snackbar(
        'Error',
        'Failed to unmute user: $e',
        backgroundColor: Colors.red.shade700,
        colorText: Colors.white,
      );
    }
  }

// Add method to send system messages to all users
  void sendSystemMessage(String text) {
    final systemMessage = ChatMessage(
      senderId: 0,
      senderName: 'System',
      message: text,
      timestamp: DateTime.now(),
      type: MessageType.system,
      isHost: false,
    );

    // Add to local messages
    messages.add(systemMessage);

    // Also send via data stream so all users see it
    _agoraService.sendChatMessage(text, 'System', false);
  }

// Enhanced participant list with proper host identification
  void refreshParticipants() {
    final list = <ParticipantInfo>[];

    if (_agoraService.isJoined.value) {
      // Add local user (could be host or audience)
      list.add(ParticipantInfo(
        uid: _agoraService.localUserId,
        name: userDisplayName.value,
        isLocal: true,
        isHost: isHost, // This should be true for host
        audioEnabled: _agoraService.isAudioEnabled.value,
        videoEnabled: _agoraService.isVideoEnabled.value || _agoraService.isScreenSharing.value,
        isScreenSharing: _agoraService.isScreenSharing.value,
      ));
    }

    for (final uid in _agoraService.remoteUserIds) {
      final state = _agoraService.userStates[uid];
      final user = _agoraService.remoteUsers[uid];

      // For now, assume first remote user is host if local user is audience
      // You might want to implement proper host detection logic
      final bool isRemoteHost = list.isEmpty && !isHost; // Simple logic - improve as needed

      list.add(ParticipantInfo(
        uid: uid,
        name: user?.name ?? 'User $uid',
        isLocal: false,
        isHost: isRemoteHost,
        audioEnabled: state?.hasAudio ?? false,
        videoEnabled: state?.hasVideo ?? false,
        isScreenSharing: false,
      ));
    }

    participantsRx.assignAll(list);
    debugPrint('=== Refreshed participants: ${list.length} users ===');
    for (final p in list) {
      debugPrint('  - ${p.name} (UID: ${p.uid}, Host: ${p.isHost}, Local: ${p.isLocal})');
    }
  }
  @override
  void onClose() {
    scrollController.dispose();
    chatController.dispose();
    super.onClose();
  }

  // void refreshParticipants() {
  //   final list = <ParticipantInfo>[];
  //
  //   if (_agoraService.isJoined.value) {
  //     list.add(ParticipantInfo(
  //       uid: _agoraService.localUserId,
  //       name: userDisplayName.value,
  //       isLocal: true,
  //       isHost: isHost,
  //       audioEnabled: _agoraService.isAudioEnabled.value,
  //       videoEnabled: _agoraService.isVideoEnabled.value || _agoraService.isScreenSharing.value,
  //       isScreenSharing: _agoraService.isScreenSharing.value,
  //     ));
  //   }
  //
  //   for (final uid in _agoraService.remoteUserIds) {
  //     final state = _agoraService.userStates[uid];
  //     final user = _agoraService.remoteUsers[uid];
  //     list.add(ParticipantInfo(
  //       uid: uid,
  //       name: user?.name ?? 'User $uid',
  //       isLocal: false,
  //       isHost: false,
  //       audioEnabled: state?.hasAudio ?? false,
  //       videoEnabled: state?.hasVideo ?? false,
  //       isScreenSharing: false,
  //     ));
  //   }
  //
  //   participantsRx.assignAll(list);
  // }

  List<ParticipantInfo> get participants => participantsRx;

  Future<bool> joinSession({
    required int sessionId,
    required String nickname,
    required String sessionTitle,
    required String token,
    required int userId,
    String role = 'audience',
  }) async {
    try {
      debugPrint('=== Joining session: $sessionId as $role ===');

      // Reset state
      isLoading.value = true;
      errorMessage.value = '';

      // Ensure we're not already joined
      if (_agoraService.isJoined.value) {
        await leaveSession();
        await Future.delayed(const Duration(milliseconds: 1000));
      }

      userRole.value = role;
      userDisplayName.value = nickname.isNotEmpty ? nickname : 'User $userId';

      final agoraRole = role == 'host'
          ? ClientRoleType.clientRoleBroadcaster
          : ClientRoleType.clientRoleAudience;

      final channelName = _cleanChannelName(sessionTitle);

      // Initialize chat before joining
      initializeChat();

      await _agoraService.joinChannel(
        token: token,
        channelName: channelName,
        uid: userId,
        role: agoraRole,
      );

      currentChannel.value = channelName;

      // Wait for connection
      await Future.delayed(const Duration(milliseconds: 2000));

      // Force refresh
      refreshParticipants();
      renderTrigger.value++;

      return true;
    } catch (e) {
      errorMessage.value = 'Failed to join: $e';
      debugPrint('=== Error joining session: $e ===');
      return false;
    } finally {
      isLoading.value = false;
    }
  }

  String _cleanChannelName(String name) {
    return name
        .replaceAll(RegExp(r'[^\w]'), '_')
        .replaceAll(RegExp(r'_+'), '_')
        .toLowerCase()
        .substring(0, name.length > 64 ? 64 : name.length);
  }

  // CHAT METHODS
  void initializeChat() {
    debugPrint('=== Initializing real-time chat ===');

    // Clear existing messages
    messages.clear();

    // Add welcome message
    addSystemMessage('Chat connected - All users can send and read messages');
  }

  void sendMessage() {
    final text = chatController.text.trim();
    if (text.isEmpty) return;

    debugPrint('=== Sending real-time chat message: $text ===');

    // Send via Agora data stream
    _agoraService.sendChatMessage(
        text,
        userDisplayName.value,
        isHost
    );

    // Add message locally immediately for better UX
    final localMessage = ChatMessage(
      senderId: _agoraService.localUserId,
      senderName: userDisplayName.value,
      message: text,
      timestamp: DateTime.now(),
      type: MessageType.user,
      isHost: isHost,
    );

    messages.add(localMessage);
    chatController.clear();

    // Auto-scroll to show new message
    scrollToBottom();

    // Update unread count if chat is hidden
    if (!showChat.value) {
      unreadCount.value++;
    }
  }

  void onChatMessageReceived(ChatMessage message) {
    // Avoid adding duplicate messages (in case we already added locally)
    final isDuplicate = messages.any((m) =>
    m.senderId == message.senderId &&
        m.message == message.message &&
        m.timestamp.difference(message.timestamp).inSeconds < 2
    );

    if (!isDuplicate) {
      messages.add(message);

      // Auto-scroll to bottom
      scrollToBottom();

      // Update unread count if chat is hidden
      if (!showChat.value) {
        unreadCount.value++;
      }

      debugPrint('=== Chat message received from ${message.senderName} ===');
    }
  }

  void scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scrollController.hasClients) {
        scrollController.animateTo(
          scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void addSystemMessage(String text) {
    final message = ChatMessage(
      senderId: 0,
      senderName: 'System',
      message: text,
      timestamp: DateTime.now(),
      type: MessageType.system,
      isHost: false,
    );

    messages.add(message);
    scrollToBottom();
  }

  Future<void> leaveSession() async {
    try {
      await _agoraService.leaveChannel();
      currentChannel.value = '';
      userDisplayName.value = '';
      userRole.value = 'audience';
      messages.clear();
      unreadCount.value = 0;
      showChat.value = false;
      showParticipants.value = false;
      selectedSpeaker.value = null;
      participantsRx.clear();
      renderTrigger.value = 0;
    } catch (e) {
      debugPrint('=== Error leaving session: $e ===');
    }
  }


  // Future<void> toggleAudio() async {
  //   try {
  //     if (!isJoined) return;
  //
  //     // Audience can unmute themselves to speak
  //     final newState = !_agoraService.isAudioEnabled.value;
  //     await _agoraService.toggleAudio();
  //
  //     addSystemMessage('${userDisplayName.value} ${newState ? "unmuted" : "muted"} mic');
  //
  //     // Force UI refresh
  //     refreshParticipants();
  //     renderTrigger.value++;
  //   } catch (e) {
  //     debugPrint('=== Error toggling audio: $e ===');
  //   }
  // }

  Future<void> toggleVideo() async {
    try {
      if (!isJoined) return;

      if (isHost) {
        // Host can toggle video normally
        await _agoraService.toggleVideo();
        addSystemMessage('${userDisplayName.value} ${_agoraService.isVideoEnabled.value ? "started" : "stopped"} video');
      } else {
        // Audience can request to enable video
        Get.snackbar(
          'Video Request',
          'Please ask the host to enable your video',
          backgroundColor: Colors.orange.shade700,
          colorText: Colors.white,
        );
      }

      refreshParticipants();
      renderTrigger.value++;
    } catch (e) {
      debugPrint('=== Error toggling video: $e ===');
    }
  }

  Future<void> toggleScreenShare() async {
    if (_agoraService.isScreenSharing.value) {
      await _agoraService.stopScreenSharing();
      addSystemMessage('Screen sharing stopped');
    } else {
      await _agoraService.startScreenSharing();
      addSystemMessage('Screen sharing started');
    }
    renderTrigger.value++;
  }

  Future<void> switchCamera() async => await _agoraService.switchCamera();

  void toggleChatPanel() {
    showChat.value = !showChat.value;
    if (showChat.value) {
      unreadCount.value = 0;
      showParticipants.value = false;
      scrollToBottom();
    }
  }

  void openChat() {
    showChat.value = true;
    unreadCount.value = 0;
    scrollToBottom();
  }

  void closeChat() {
    showChat.value = false;
  }

  void toggleParticipantsPanel() {
    showParticipants.value = !showParticipants.value;
    if (showParticipants.value) showChat.value = false;
  }

  void switchViewMode() {
    viewMode.value = viewMode.value == 'grid' ? 'speaker' : 'grid';
  }

  void switchToGridView() {
    viewMode.value = 'grid';
  }

  void switchToSpeakerView() {
    viewMode.value = 'speaker';
  }

  void selectParticipant(ParticipantInfo participant) {
    selectedSpeaker.value = participant;
    viewMode.value = 'speaker';
  }

  void selectSpeaker(ParticipantInfo p) => selectedSpeaker.value = p;

  // HOST CONTROLS
  // Future<void> muteUserAudio(int uid) async {
  //   try {
  //     if (!isHost) return;
  //
  //     if (uid != _agoraService.localUserId) {
  //       await _agoraService.engine.muteRemoteAudioStream(uid: uid, mute: true);
  //       addSystemMessage('Muted audio for user $uid');
  //     }
  //   } catch (e) {
  //     debugPrint('=== Error muting user audio: $e ===');
  //   }
  // }
  //
  // Future<void> unmuteUserAudio(int uid) async {
  //   try {
  //     if (!isHost) return;
  //
  //     if (uid != _agoraService.localUserId) {
  //       await _agoraService.engine.muteRemoteAudioStream(uid: uid, mute: false);
  //       addSystemMessage('Unmuted audio for user $uid');
  //     }
  //   } catch (e) {
  //     debugPrint('=== Error unmuting user audio: $e ===');
  //   }
  // }


  Future<void> removeUser(int uid) async {
    try {
      if (!isHost) return;
      addSystemMessage('Removed user $uid from session');
    } catch (e) {
      debugPrint('=== Error removing user: $e ===');
    }
  }

  // DEBUG METHODS
  void checkVideoStatus() {
    debugPrint('=== VIDEO STATUS CHECK ===');
    debugPrint('isJoined: $isJoined');
    debugPrint('isLoading: ${isLoading.value}');
    debugPrint('Local User ID: ${_agoraService.localUserId}');
    debugPrint('Video Enabled: ${_agoraService.isVideoEnabled.value}');
    debugPrint('Audio Enabled: ${_agoraService.isAudioEnabled.value}');
    debugPrint('Participants Count: ${participants.length}');
    debugPrint('Chat Messages Count: ${messages.length}');

    for (final participant in participants) {
      debugPrint('Participant ${participant.uid}: '
          'Name: ${participant.name}, '
          'Local: ${participant.isLocal}, '
          'Video: ${participant.videoEnabled}, '
          'Audio: ${participant.audioEnabled}');
    }
  }

  bool get canToggleVideo => isJoined && isHost && !_agoraService.isScreenSharing.value;
  bool get canScreenShare => isJoined && isHost;
  bool get canSwitchCamera => isJoined && isHost && _agoraService.isVideoEnabled.value;
}

// DATA MODELS (Add these if not already present)
class ChatMessage {
  final int senderId;
  final String senderName;
  final String message;
  final DateTime timestamp;
  final MessageType type;
  final bool isHost;

  ChatMessage({
    required this.senderId,
    required this.senderName,
    required this.message,
    required this.timestamp,
    required this.type,
    required this.isHost,
  });
}

enum MessageType { user, system }

class ParticipantInfo {
  final int uid;
  final String name;
  final bool isLocal;
  final bool isHost;
  final bool audioEnabled;
  final bool videoEnabled;
  final bool isScreenSharing;

  ParticipantInfo({
    required this.uid,
    required this.name,
    required this.isLocal,
    required this.isHost,
    required this.audioEnabled,
    required this.videoEnabled,
    required this.isScreenSharing,
  });

  String get displayName => '$name${isLocal ? " (You)" : ""}${isHost ? " [Host]" : ""}';
  String get firstChar => name.isNotEmpty ? name[0].toUpperCase() : 'U';
}


// import 'package:agora_rtc_engine/agora_rtc_engine.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
//
// import '../../services/live_streaming_services/agora_services.dart';
//
// class AgoraViewModel extends GetxController {
//   final AgoraService _agoraService = Get.find<AgoraService>();
//
//   final RxBool isLoading = false.obs;
//   final RxString errorMessage = ''.obs;
//   final RxString currentChannel = ''.obs;
//   final RxString userDisplayName = ''.obs;
//   final RxString userRole = 'audience'.obs;
//
//   // Chat
//   final RxList<ChatMessage> messages = <ChatMessage>[].obs;
//   final TextEditingController chatController = TextEditingController();
//   final RxInt unreadCount = 0.obs;
//   final RxBool showChat = false.obs;
//
//   // Participants
//   final RxBool showParticipants = false.obs;
//   final RxString viewMode = 'grid'.obs;
//   final Rx<ParticipantInfo?> selectedSpeaker = Rx<ParticipantInfo?>(null);
//
//   // REACTIVE PARTICIPANTS LIST
//   final RxList<ParticipantInfo> participantsRx = <ParticipantInfo>[].obs;
//
//   // CRITICAL: Force UI rebuild trigger
//   final RxInt renderTrigger = 0.obs;
//
//   AgoraService get agoraService => _agoraService;
// // In AgoraViewModel - Make sure this getter exists
//   bool get isJoined => _agoraService.isJoined.value;
//   bool get isHost => userRole.value == 'host';
//
// // // Add this method for debugging
// //   void checkVideoStatus() {
// //     debugPrint('=== VIDEO STATUS CHECK ===');
// //     debugPrint('isJoined: $isJoined');
// //     debugPrint('isLoading: ${isLoading.value}');
// //     debugPrint('Local User ID: ${_agoraService.localUserId}');
// //     debugPrint('Video Enabled: ${_agoraService.isVideoEnabled.value}');
// //     debugPrint('Audio Enabled: ${_agoraService.isAudioEnabled.value}');
// //     debugPrint('Participants Count: ${participants.length}');
// //
// //     for (final participant in participants) {
// //       debugPrint('Participant ${participant.uid}: '
// //           'Name: ${participant.name}, '
// //           'Local: ${participant.isLocal}, '
// //           'Video: ${participant.videoEnabled}, '
// //           'Audio: ${participant.audioEnabled}');
// //     }
// //   }
//
//   // In AgoraViewModel - ADD these host control methods:
//
// // In AgoraViewModel - ADD THESE METHODS:
// // Add method to clear unread count when opening chat
//
//   // Replace the initializeChat method
//   void initializeChat() {
//     debugPrint('=== Initializing real-time chat ===');
//
//     // Clear existing messages
//     messages.clear();
//
//     // Add welcome message
//     addSystemMessage('Chat connected - All users can send and read messages');
//   }
//
// // Replace the sendMessage method
//   void sendMessage() {
//     final text = chatController.text.trim();
//     if (text.isEmpty) return;
//
//     debugPrint('=== Sending real-time chat message: $text ===');
//
//     // Send via Agora data stream
//     _agoraService.sendChatMessage(
//         text,
//         userDisplayName.value,
//         isHost
//     );
//
//     // Add message locally immediately for better UX
//     final localMessage = ChatMessage(
//       senderId: _agoraService.localUserId,
//       senderName: userDisplayName.value,
//       message: text,
//       timestamp: DateTime.now(),
//       type: MessageType.user,
//       isHost: isHost,
//     );
//
//     messages.add(localMessage);
//     chatController.clear();
//
//     // Update unread count if chat is hidden
//     if (!showChat.value) {
//       unreadCount.value++;
//     }
//   }
//
// // Add this method to handle incoming messages
//   void onChatMessageReceived(ChatMessage message) {
//     // Avoid adding duplicate messages (in case we already added locally)
//     final isDuplicate = messages.any((m) =>
//     m.senderId == message.senderId &&
//         m.message == message.message &&
//         m.timestamp.difference(message.timestamp).inSeconds < 2
//     );
//
//     if (!isDuplicate) {
//       messages.add(message);
//
//       // Update unread count if chat is hidden
//       if (!showChat.value) {
//         unreadCount.value++;
//       }
//
//       debugPrint('=== Chat message received from ${message.senderName} ===');
//     }
//   }
//   void openChat() {
//     showChat.value = true;
//     unreadCount.value = 0;
//   }
//
//   void closeChat() {
//     showChat.value = false;
//   }
//
// // Add view mode switching
//   void switchToGridView() {
//     viewMode.value = 'grid';
//   }
//
//   void switchToSpeakerView() {
//     viewMode.value = 'speaker';
//   }
//
// // Add method to handle participant selection
//   void selectParticipant(ParticipantInfo participant) {
//     selectedSpeaker.value = participant;
//     viewMode.value = 'speaker';
//   }
// // Complete host control methods
//   Future<void> muteUserAudio(int uid) async {
//     try {
//       if (!isHost) return;
//
//       if (uid != _agoraService.localUserId) {
//         await _agoraService.engine.muteRemoteAudioStream(uid: uid, mute: true);
//         addSystemMessage('Muted audio for user $uid');
//       }
//     } catch (e) {
//       debugPrint('=== Error muting user audio: $e ===');
//     }
//   }
//
//   Future<void> unmuteUserAudio(int uid) async {
//     try {
//       if (!isHost) return;
//
//       if (uid != _agoraService.localUserId) {
//         await _agoraService.engine.muteRemoteAudioStream(uid: uid, mute: false);
//         addSystemMessage('Unmuted audio for user $uid');
//       }
//     } catch (e) {
//       debugPrint('=== Error unmuting user audio: $e ===');
//     }
//   }
//
//   Future<void> muteUserVideo(int uid) async {
//     try {
//       if (!isHost) return;
//
//       if (uid != _agoraService.localUserId) {
//         await _agoraService.engine.muteRemoteVideoStream(uid: uid, mute: true);
//         addSystemMessage('Muted video for user $uid');
//       }
//     } catch (e) {
//       debugPrint('=== Error muting user video: $e ===');
//     }
//   }
//
//   Future<void> unmuteUserVideo(int uid) async {
//     try {
//       if (!isHost) return;
//
//       if (uid != _agoraService.localUserId) {
//         await _agoraService.engine.muteRemoteVideoStream(uid: uid, mute: false);
//         addSystemMessage('Unmuted video for user $uid');
//       }
//     } catch (e) {
//       debugPrint('=== Error unmuting user video: $e ===');
//     }
//   }
//
//   Future<void> removeUser(int uid) async {
//     try {
//       if (!isHost) return;
//       addSystemMessage('Removed user $uid from session');
//     } catch (e) {
//       debugPrint('=== Error removing user: $e ===');
//     }
//   }
//
//
//   @override
//   void onInit() {
//     super.onInit();
//     debugPrint('=== AgoraViewModel initialized ===');
//
//     // Auto-refresh participants on any change
//     ever(_agoraService.isJoined, (_) {
//       refreshParticipants();
//       renderTrigger.value++; // Force UI rebuild
//     });
//     ever(_agoraService.isAudioEnabled, (_) => refreshParticipants());
//     ever(_agoraService.isVideoEnabled, (_) {
//       refreshParticipants();
//       renderTrigger.value++; // Force UI rebuild
//     });
//     ever(_agoraService.isScreenSharing, (_) => refreshParticipants());
//     ever(_agoraService.remoteUsers, (_) {
//       refreshParticipants();
//       renderTrigger.value++; // Force UI rebuild
//     });
//     ever(_agoraService.userStates, (_) => refreshParticipants());
//   }
//
//   void refreshParticipants() {
//     final list = <ParticipantInfo>[];
//
//     if (_agoraService.isJoined.value) {
//       list.add(ParticipantInfo(
//         uid: _agoraService.localUserId,
//         name: userDisplayName.value,
//         isLocal: true,
//         isHost: isHost,
//         audioEnabled: _agoraService.isAudioEnabled.value,
//         videoEnabled: _agoraService.isVideoEnabled.value || _agoraService.isScreenSharing.value,
//         isScreenSharing: _agoraService.isScreenSharing.value,
//       ));
//     }
//
//     for (final uid in _agoraService.remoteUserIds) {
//       final state = _agoraService.userStates[uid];
//       final user = _agoraService.remoteUsers[uid];
//       list.add(ParticipantInfo(
//         uid: uid,
//         name: user?.name ?? 'User $uid',
//         isLocal: false,
//         isHost: false,
//         audioEnabled: state?.hasAudio ?? false,
//         videoEnabled: state?.hasVideo ?? false,
//         isScreenSharing: false,
//       ));
//     }
//
//     participantsRx.assignAll(list);
//   }
//
//   List<ParticipantInfo> get participants => participantsRx;
//
// // In AgoraViewModel - ADD THESE CRITICAL FIXES
//
//
// // Update the joinSession method to ensure proper state
//   Future<bool> joinSession({
//     required int sessionId,
//     required String nickname,
//     required String sessionTitle,
//     required String token,
//     required int userId,
//     String role = 'audience',
//   }) async {
//     try {
//       debugPrint('=== Joining session: $sessionId as $role ===');
//
//       // Reset state
//       isLoading.value = true;
//       errorMessage.value = '';
//
//       // Ensure we're not already joined
//       if (_agoraService.isJoined.value) {
//         await leaveSession();
//         await Future.delayed(const Duration(milliseconds: 1000));
//       }
//
//       userRole.value = role;
//       userDisplayName.value = nickname.isNotEmpty ? nickname : 'User $userId';
//
//       final agoraRole = role == 'host'
//           ? ClientRoleType.clientRoleBroadcaster
//           : ClientRoleType.clientRoleAudience;
//
//       final channelName = _cleanChannelName(sessionTitle);
//
//       await _agoraService.joinChannel(
//         token: token,
//         channelName: channelName,
//         uid: userId,
//         role: agoraRole,
//       );
//
//       currentChannel.value = channelName;
//
//       // Wait for connection
//       await Future.delayed(const Duration(milliseconds: 2000));
//
//       // Force refresh
//       refreshParticipants();
//       renderTrigger.value++;
//
//       return true;
//     } catch (e) {
//       errorMessage.value = 'Failed to join: $e';
//       debugPrint('=== Error joining session: $e ===');
//       return false;
//     } finally {
//       isLoading.value = false;
//     }
//   }
//
//
//
// // And add the debug method
//   void checkVideoStatus() {
//     debugPrint('=== VIDEO STATUS CHECK ===');
//     debugPrint('isJoined: $isJoined');
//     debugPrint('isLoading: ${isLoading.value}');
//     debugPrint('Local User ID: ${_agoraService.localUserId}');
//     debugPrint('Video Enabled: ${_agoraService.isVideoEnabled.value}');
//     debugPrint('Audio Enabled: ${_agoraService.isAudioEnabled.value}');
//     debugPrint('Participants Count: ${participants.length}');
//
//     for (final participant in participants) {
//       debugPrint('Participant ${participant.uid}: '
//           'Name: ${participant.name}, '
//           'Local: ${participant.isLocal}, '
//           'Video: ${participant.videoEnabled}, '
//           'Audio: ${participant.audioEnabled}');
//     }
//   }
//
//   String _cleanChannelName(String name) {
//     return name
//         .replaceAll(RegExp(r'[^\w]'), '_')
//         .replaceAll(RegExp(r'_+'), '_')
//         .toLowerCase()
//         .substring(0, name.length > 64 ? 64 : name.length);
//   }
//
//   Future<void> leaveSession() async {
//     try {
//       await _agoraService.leaveChannel();
//       currentChannel.value = '';
//       userDisplayName.value = '';
//       userRole.value = 'audience';
//       messages.clear();
//       unreadCount.value = 0;
//       showChat.value = false;
//       showParticipants.value = false;
//       selectedSpeaker.value = null;
//       participantsRx.clear();
//       renderTrigger.value = 0;
//     } catch (e) {
//       debugPrint('=== Error leaving session: $e ===');
//     }
//   }
//
//   // Allow audience to toggle audio
//   Future<void> toggleAudio() async {
//     try {
//       if (!isJoined) return;
//
//       // Audience can unmute themselves to speak
//       final newState = !_agoraService.isAudioEnabled.value;
//       await _agoraService.toggleAudio();
//
//       addSystemMessage('${userDisplayName.value} ${newState ? "unmuted" : "muted"} mic');
//
//       // Force UI refresh
//       refreshParticipants();
//       renderTrigger.value++;
//     } catch (e) {
//       debugPrint('=== Error toggling audio: $e ===');
//     }
//   }
//
// // Allow audience to request video (if needed)
//   Future<void> toggleVideo() async {
//     try {
//       if (!isJoined) return;
//
//       if (isHost) {
//         // Host can toggle video normally
//         await _agoraService.toggleVideo();
//         addSystemMessage('${userDisplayName.value} ${_agoraService.isVideoEnabled.value ? "started" : "stopped"} video');
//       } else {
//         // Audience can request to enable video (you might want to show a dialog)
//         Get.snackbar(
//           'Video Request',
//           'Please ask the host to enable your video',
//           backgroundColor: Colors.orange.shade700,
//           colorText: Colors.white,
//         );
//       }
//
//       refreshParticipants();
//       renderTrigger.value++;
//     } catch (e) {
//       debugPrint('=== Error toggling video: $e ===');
//     }
//   }
//
//
//   Future<void> toggleScreenShare() async {
//     if (_agoraService.isScreenSharing.value) {
//       await _agoraService.stopScreenSharing();
//       addSystemMessage('Screen sharing stopped');
//     } else {
//       await _agoraService.startScreenSharing();
//       addSystemMessage('Screen sharing started');
//     }
//     renderTrigger.value++;
//   }
//
//   Future<void> switchCamera() async => await _agoraService.switchCamera();
//
//
//   void addSystemMessage(String text) {
//     messages.add(ChatMessage(
//       senderId: 0,
//       senderName: 'System',
//       message: text,
//       timestamp: DateTime.now(),
//       type: MessageType.system,
//       isHost: false,
//     ));
//   }
//
//   void toggleChatPanel() {
//     showChat.value = !showChat.value;
//     if (showChat.value) {
//       unreadCount.value = 0;
//       showParticipants.value = false;
//     }
//   }
//
//   void toggleParticipantsPanel() {
//     showParticipants.value = !showParticipants.value;
//     if (showParticipants.value) showChat.value = false;
//   }
//
//   void switchViewMode() {
//     viewMode.value = viewMode.value == 'grid' ? 'speaker' : 'grid';
//   }
//
//   void selectSpeaker(ParticipantInfo p) => selectedSpeaker.value = p;
// // In AgoraViewModel - Ensure chat methods work:
//
//   // void sendMessage() {
//   //   final text = chatController.text.trim();
//   //   if (text.isEmpty) return;
//   //
//   //   final message = ChatMessage(
//   //     senderId: _agoraService.localUserId,
//   //     senderName: userDisplayName.value,
//   //     message: text,
//   //     timestamp: DateTime.now(),
//   //     type: MessageType.user,
//   //     isHost: isHost,
//   //   );
//   //
//   //   messages.add(message);
//   //   chatController.clear();
//   //
//   //   // Update unread count if chat is hidden
//   //   if (!showChat.value) {
//   //     unreadCount.value++;
//   //   }
//   //
//   //   debugPrint('=== Message sent: $text ===');
//   // }
//
//  get canToggleVideo => isJoined && isHost && !_agoraService.isScreenSharing.value;
//   bool get canScreenShare => isJoined && isHost;
//   bool get canSwitchCamera => isJoined && isHost && _agoraService.isVideoEnabled.value;
// }
//
// class ChatMessage {
//   final int senderId;
//   final String senderName;
//   final String message;
//   final DateTime timestamp;
//   final MessageType type;
//   final bool isHost;
//
//   ChatMessage({
//     required this.senderId,
//     required this.senderName,
//     required this.message,
//     required this.timestamp,
//     required this.type,
//     required this.isHost,
//   });
// }
//
// enum MessageType { user, system }
//
// class ParticipantInfo {
//   final int uid;
//   final String name;
//   final bool isLocal;
//   final bool isHost;
//   final bool audioEnabled;
//   final bool videoEnabled;
//   final bool isScreenSharing;
//
//   ParticipantInfo({
//     required this.uid,
//     required this.name,
//     required this.isLocal,
//     required this.isHost,
//     required this.audioEnabled,
//     required this.videoEnabled,
//     required this.isScreenSharing,
//   });
//
//   String get displayName => '$name${isLocal ? " (You)" : ""}${isHost ? " [Host]" : ""}';
//   String get firstChar => name.isNotEmpty ? name[0].toUpperCase() : 'U';
// }
//
