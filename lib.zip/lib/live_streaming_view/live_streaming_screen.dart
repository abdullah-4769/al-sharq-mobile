// live_streaming_screen.dart

// REPLACE your entire LiveStreamingScreen with this clean version:

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:permission_handler/permission_handler.dart';

import '../view_model/live_streaming_viewmodel/agora_viewmodel.dart';

class LiveStreamingScreen extends StatefulWidget {
  final int sessionId;
  final String sessionTitle;
  final String userName;
  final String token;
  final int userId;
  final String userRole;

  const LiveStreamingScreen({
    Key? key,
    required this.sessionId,
    required this.sessionTitle,
    required this.userName,
    required this.token,
    required this.userId,
    required this.userRole,
  }) : super(key: key);

  @override
  State<LiveStreamingScreen> createState() => _LiveStreamingScreenState();
}

class _LiveStreamingScreenState extends State<LiveStreamingScreen> {
  final AgoraViewModel _viewModel = Get.find<AgoraViewModel>();
  bool _isInitialized = false;

  @override
  void initState() {
    super.initState();
    debugPrint('=== LiveStreamingScreen initState ===');
    _initializeAgora();
  }

  Future<void> _initializeAgora() async {
    if (_isInitialized) {
      debugPrint('=== Already initialized, skipping ===');
      return;
    }

    debugPrint('=== Requesting permissions ===');
    final statuses = await [
      Permission.microphone,
      Permission.camera,
    ].request();

    debugPrint(
        '=== Permission status - Camera: ${statuses[Permission.camera]}, '
            'Microphone: ${statuses[Permission.microphone]} ===');

    if (statuses[Permission.microphone]!.isDenied ||
        statuses[Permission.camera]!.isDenied) {
      _showPermissionDialog();
      return;
    }

    debugPrint(
        '=== Joining session with params: ${widget.sessionId}, ${widget.userName}, ${widget.userRole} ===');

    try {
      final success = await _viewModel.joinSession(
        sessionId: widget.sessionId,
        nickname: widget.userName,
        sessionTitle: widget.sessionTitle,
        token: widget.token,
        userId: widget.userId,
        role: widget.userRole,
      );

      if (!success && mounted) {
        debugPrint('=== Failed to join session ===');
        Get.snackbar(
          'Error',
          'Failed to join session',
          backgroundColor: Colors.red.shade700,
          colorText: Colors.white,
          snackPosition: SnackPosition.TOP,
        );
      } else {
        _isInitialized = true;
        debugPrint('=== Session initialization completed ===');
      }
    } catch (e) {
      debugPrint('=== Error initializing Agora: $e ===');
      if (mounted) {
        Get.snackbar(
          'Error',
          'Failed to initialize video: $e',
          backgroundColor: Colors.red.shade700,
          colorText: Colors.white,
          snackPosition: SnackPosition.TOP,
        );
      }
    }
  }

  void _showPermissionDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Permissions Required'),
        content: const Text(
          'Camera and microphone permissions are required for live streaming.',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              openAppSettings();
            },
            child: const Text('Open Settings'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    debugPrint('=== LiveStreamingScreen dispose ===');
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        debugPrint('=== Back button pressed, leaving session ===');
        await _viewModel.leaveSession();
        return true;
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: Column(
            children: [
              // Header
              _buildHeader(),

              // Video Area
              Expanded(
                child: Obx(() {
                  if (_viewModel.isLoading.value) return _buildLoadingScreen();
                  if (!_viewModel.isJoined && _viewModel.errorMessage.value.isNotEmpty)
                    return _buildErrorScreen();
                  return _buildVideoArea();
                }),
              ),

              // Controls
              Obx(() => _viewModel.isJoined ? _buildControls() : const SizedBox()),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() => Container(
    padding: const EdgeInsets.all(16),
    color: Colors.black.withOpacity(0.8),
    child: Row(
      children: [
        IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () async {
            await _viewModel.leaveSession();
            if (mounted) Navigator.pop(context);
          },
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                widget.sessionTitle,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),
              Obx(() => Row(
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: _viewModel.isJoined
                          ? Colors.green.shade600
                          : Colors.red.shade600,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    _viewModel.isJoined
                        ? '${_viewModel.participants.length} participants'
                        : 'Connecting...',
                    style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey.shade300
                    ),
                  ),
                ],
              )),
            ],
          ),
        ),
        // DEBUG BUTTON
        IconButton(
          icon: const Icon(Icons.bug_report, color: Colors.white),
          onPressed: () {
            debugPrint('=== DEBUG INFO ===');
            debugPrint('isJoined: ${_viewModel.isJoined}');
            debugPrint('isLoading: ${_viewModel.isLoading.value}');
            debugPrint('Participants: ${_viewModel.participants.length}');
            _viewModel.checkVideoStatus();
          },
        ),
      ],
    ),
  );

  Widget _buildVideoArea() => Container(
    color: Colors.grey.shade900,
    child: Obx(() {
      final participants = _viewModel.participants;
      debugPrint('=== Video Area - Participants: ${participants.length} ===');

      if (participants.isEmpty) {
        return _buildEmptyState();
      }

      return _buildParticipantView(participants.first);
    }),
  );

  Widget _buildParticipantView(ParticipantInfo participant) {
    return Stack(
      fit: StackFit.expand,
      children: [
        _buildVideoContent(participant),
        Positioned(
          bottom: 20,
          left: 20,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.7),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              participant.displayName,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ),
        if (!participant.audioEnabled)
          Positioned(
            top: 20,
            right: 20,
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.7),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.mic_off, color: Colors.white, size: 20),
            ),
          ),
      ],
    );
  }

  Widget _buildVideoContent(ParticipantInfo participant) {
    final engine = _viewModel.agoraService.engine;

    debugPrint('=== Building video for: ${participant.uid}, '
        'isLocal: ${participant.isLocal}, '
        'videoEnabled: ${participant.videoEnabled} ===');

    try {
      if (participant.videoEnabled) {
        if (participant.isLocal) {
          debugPrint('=== Creating LOCAL video view ===');
          return AgoraVideoView(
            controller: VideoViewController(
              rtcEngine: engine,
              canvas: const VideoCanvas(uid: 0),
            ),
          );
        } else {
          debugPrint('=== Creating REMOTE video view for: ${participant.uid} ===');
          return AgoraVideoView(
            controller: VideoViewController.remote(
              rtcEngine: engine,
              canvas: VideoCanvas(uid: participant.uid),
              connection: RtcConnection(
                channelId: _viewModel.currentChannel.value,
              ),
            ),
          );
        }
      } else {
        return _buildAvatar(participant);
      }
    } catch (e) {
      debugPrint('=== Error creating video view: $e ===');
      return _buildErrorVideoState(participant, e.toString());
    }
  }

  Widget _buildAvatar(ParticipantInfo participant) => Container(
    color: Colors.grey.shade800,
    child: Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: participant.isHost
                  ? Colors.red.shade700
                  : Colors.blue.shade700,
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                participant.firstChar,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            participant.displayName,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    ),
  );

  Widget _buildErrorVideoState(ParticipantInfo participant, String error) => Container(
    color: Colors.grey.shade800,
    child: Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.error_outline, color: Colors.red, size: 48),
          const SizedBox(height: 16),
          Text(
            'Video Error',
            style: TextStyle(
              color: Colors.grey.shade300,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            error.length > 50 ? '${error.substring(0, 50)}...' : error,
            style: TextStyle(
              color: Colors.grey.shade500,
              fontSize: 12,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    ),
  );

  Widget _buildControls() => Container(
    padding: const EdgeInsets.all(16),
    color: Colors.black.withOpacity(0.9),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _buildControlButton(
          icon: _viewModel.agoraService.isAudioEnabled.value
              ? Icons.mic
              : Icons.mic_off,
          label: 'Mic',
          isActive: _viewModel.agoraService.isAudioEnabled.value,
          onPressed: _viewModel.toggleAudio,
        ),

        _buildControlButton(
          icon: _viewModel.agoraService.isVideoEnabled.value
              ? Icons.videocam
              : Icons.videocam_off,
          label: 'Camera',
          isActive: _viewModel.agoraService.isVideoEnabled.value,
          onPressed: _viewModel.isHost ? _viewModel.toggleVideo : null,
        ),

        _buildControlButton(
          icon: Icons.call_end,
          label: 'Leave',
          backgroundColor: Colors.red.shade700,
          onPressed: () async {
            await _viewModel.leaveSession();
            if (mounted) Navigator.pop(context);
          },
        ),
      ],
    ),
  );

  Widget _buildControlButton({
    required IconData icon,
    required String label,
    VoidCallback? onPressed,
    bool isActive = false,
    Color? backgroundColor,
  }) {
    final btnColor = backgroundColor ?? (isActive ? Colors.white : Colors.grey.shade800);
    final iconColor = backgroundColor != null ? Colors.white :
    (isActive ? Colors.black : Colors.white);

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            color: btnColor,
            shape: BoxShape.circle,
          ),
          child: IconButton(
            icon: Icon(icon, size: 24),
            color: iconColor,
            onPressed: onPressed,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  Widget _buildEmptyState() => Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 80,
          height: 80,
          decoration: BoxDecoration(
            color: Colors.grey.shade800,
            shape: BoxShape.circle,
          ),
          child: Icon(Icons.people_outline,
              size: 40, color: Colors.grey.shade600),
        ),
        const SizedBox(height: 16),
        Text('Waiting for participants...',
            style: TextStyle(color: Colors.grey.shade500, fontSize: 16)),
      ],
    ),
  );

  Widget _buildLoadingScreen() => Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation<Color>(Colors.red.shade700),
          strokeWidth: 3,
        ),
        const SizedBox(height: 24),
        const Text('Joining session...',
            style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w500)),
        const SizedBox(height: 8),
        Text('Please wait',
            style: TextStyle(color: Colors.grey.shade400, fontSize: 14)),
      ],
    ),
  );

  Widget _buildErrorScreen() => Container(
    padding: const EdgeInsets.all(24),
    child: Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: Colors.red.shade900.withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.error_outline,
                color: Colors.red.shade400, size: 40),
          ),
          const SizedBox(height: 24),
          const Text('Connection Failed',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Obx(() => Text(
            _viewModel.errorMessage.value.isNotEmpty
                ? _viewModel.errorMessage.value
                : 'Unable to join the session',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.grey.shade400, fontSize: 14),
          )),
          const SizedBox(height: 32),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              OutlinedButton.icon(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.arrow_back),
                label: const Text('Go Back'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white,
                  side: const BorderSide(color: Colors.white),
                  padding: const EdgeInsets.symmetric(
                      horizontal: 24, vertical: 12),
                ),
              ),
              const SizedBox(width: 16),
              ElevatedButton.icon(
                onPressed: _initializeAgora,
                icon: const Icon(Icons.refresh),
                label: const Text('Retry'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red.shade700,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 24, vertical: 12),
                ),
              ),
            ],
          ),
        ],
      ),
    ),
  );
}
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:agora_rtc_engine/agora_rtc_engine.dart';
// import 'package:permission_handler/permission_handler.dart';
//
// import '../view_model/live_streaming_viewmodel/agora_viewmodel.dart';
//
//
// class LiveStreamingScreen extends StatefulWidget {
//   final int sessionId;
//   final String sessionTitle;
//   final String userName;
//
//   const LiveStreamingScreen({
//     Key? key,
//     required this.sessionId,
//     required this.sessionTitle,
//     required this.userName,
//   }) : super(key: key);
//
//   @override
//   State<LiveStreamingScreen> createState() => _LiveStreamingScreenState();
// }
//
// class _LiveStreamingScreenState extends State<LiveStreamingScreen> {
//   final AgoraViewModel _viewModel = Get.find<AgoraViewModel>();
//
//   @override
//   void initState() {
//     super.initState();
//     _initializeAgora();
//   }
//
//   Future<void> _initializeAgora() async {
//     await [Permission.microphone, Permission.camera].request();
//
//     final success = await _viewModel.joinSession(
//       sessionId: widget.sessionId,
//       nickname: widget.userName.isNotEmpty ? widget.userName : 'User',
//       sessionTitle: widget.sessionTitle,
//     );
//
//     if (!success) {
//       Get.back();
//       Get.snackbar(
//         'Error',
//         'Failed to join session',
//         backgroundColor: Colors.red,
//         colorText: Colors.white,
//       );
//     }
//   }
//
//   @override
//   void dispose() {
//     _viewModel.leaveSession();
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.black,
//       body: Obx(() {
//         if (_viewModel.isLoading.value) {
//           return _buildLoadingScreen();
//         }
//
//         if (!_viewModel.isJoined) {
//           return _buildErrorScreen();
//         }
//
//         return _buildMainInterface();
//       }),
//     );
//   }
//
//   Widget _buildLoadingScreen() {
//     return Center(
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           CircularProgressIndicator(
//             valueColor: AlwaysStoppedAnimation<Color>(Colors.red[700]!),
//           ),
//           SizedBox(height: 16),
//           Text(
//             'Joining session...',
//             style: TextStyle(
//               color: Colors.white,
//               fontSize: 16,
//             ),
//           ),
//         ],
//       ),
//     );
//   }
//
//   Widget _buildErrorScreen() {
//     return Center(
//       child: Padding(
//         padding: EdgeInsets.all(16),
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Icon(
//               Icons.error_outline,
//               color: Colors.red,
//               size: 64,
//             ),
//             SizedBox(height: 16),
//             Text(
//               'Failed to join session',
//               style: TextStyle(
//                 color: Colors.white,
//                 fontSize: 18,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             SizedBox(height: 8),
//             Text(
//               _viewModel.errorMessage.value,
//               textAlign: TextAlign.center,
//               style: TextStyle(color: Colors.white70),
//             ),
//             SizedBox(height: 24),
//             Row(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 ElevatedButton(
//                   onPressed: () => Get.back(),
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor: Colors.red[700],
//                     foregroundColor: Colors.white,
//                   ),
//                   child: Row(
//                     children: [
//                       Icon(Icons.arrow_back, size: 20),
//                       SizedBox(width: 8),
//                       Text('Back'),
//                     ],
//                   ),
//                 ),
//                 SizedBox(width: 12),
//                 ElevatedButton(
//                   onPressed: () => _initializeAgora(),
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor: Colors.grey[700],
//                     foregroundColor: Colors.white,
//                   ),
//                   child: Row(
//                     children: [
//                       Icon(Icons.refresh, size: 20),
//                       SizedBox(width: 8),
//                       Text('Retry'),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget _buildMainInterface() {
//     return Stack(
//       children: [
//         _buildVideoGrid(),
//         _buildHeader(),
//         _buildControls(),
//         _buildSidePanels(),
//       ],
//     );
//   }
//
//   Widget _buildHeader() {
//     return Positioned(
//       top: MediaQuery.of(context).padding.top,
//       left: 0,
//       right: 0,
//       child: Container(
//         padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
//         decoration: BoxDecoration(
//           color: Colors.black.withOpacity(0.7),
//           border: Border(bottom: BorderSide(color: Colors.grey[800]!)),
//         ),
//         child: Row(
//           children: [
//             Expanded(
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(
//                     'Session ${widget.sessionTitle}',
//                     style: TextStyle(
//                       fontSize: 18,
//                       fontWeight: FontWeight.bold,
//                       color: Colors.white,
//                     ),
//                   ),
//                   Obx(() => Text(
//                     'Now Live • ${_viewModel.participants.length} participant${_viewModel.participants.length != 1 ? 's' : ''}',
//                     style: TextStyle(
//                       fontSize: 12,
//                       color: Colors.green[400],
//                     ),
//                   )),
//                 ],
//               ),
//             ),
//             Container(
//               padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//               decoration: BoxDecoration(
//                 color: Colors.red[700],
//                 borderRadius: BorderRadius.circular(20),
//               ),
//               child: Row(
//                 children: [
//                   Icon(Icons.circle, color: Colors.white, size: 12),
//                   SizedBox(width: 6),
//                   Text(
//                     'Live',
//                     style: TextStyle(
//                       color: Colors.white,
//                       fontSize: 12,
//                       fontWeight: FontWeight.bold,
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget _buildVideoGrid() {
//     return Container(
//       color: Colors.black,
//       margin: EdgeInsets.only(
//         top: MediaQuery.of(context).padding.top + 60,
//         bottom: 80,
//       ),
//       child: Obx(() {
//         final participants = _viewModel.participants;
//
//         if (participants.isEmpty) {
//           return Center(
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 Icon(Icons.people, size: 64, color: Colors.grey[700]),
//                 SizedBox(height: 16),
//                 Text(
//                   'Waiting for participants...',
//                   style: TextStyle(color: Colors.grey[500], fontSize: 16),
//                 ),
//               ],
//             ),
//           );
//         }
//
//         return _buildHostWithParticipantsGrid(participants);
//       }),
//     );
//   }
//
//   Widget _buildHostWithParticipantsGrid(List<ParticipantInfo> participants) {
//     // Find host (first user) and other participants
//     final host = participants.firstWhere(
//           (p) => p.isLocal,
//       orElse: () => participants.first,
//     );
//
//     final otherParticipants = participants.where((p) => !p.isLocal).toList();
//
//     return Column(
//       children: [
//         // Host (Large View)
//         Expanded(
//           flex: 3,
//           child: Padding(
//             padding: EdgeInsets.all(8),
//             child: _buildParticipantTile(host, isHost: true),
//           ),
//         ),
//
//         // Other Participants (Horizontal Scroll)
//         if (otherParticipants.isNotEmpty)
//           Container(
//             height: 120,
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Padding(
//                   padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
//                   child: Text(
//                     'Participants (${otherParticipants.length})',
//                     style: TextStyle(
//                       color: Colors.white,
//                       fontSize: 14,
//                       fontWeight: FontWeight.bold,
//                     ),
//                   ),
//                 ),
//                 Expanded(
//                   child: ListView.builder(
//                     scrollDirection: Axis.horizontal,
//                     padding: EdgeInsets.symmetric(horizontal: 8),
//                     itemCount: otherParticipants.length,
//                     itemBuilder: (context, index) {
//                       return Container(
//                         width: 100,
//                         margin: EdgeInsets.symmetric(horizontal: 4),
//                         child: _buildParticipantTile(otherParticipants[index]),
//                       );
//                     },
//                   ),
//                 ),
//               ],
//             ),
//           ),
//       ],
//     );
//   }
//
//   Widget _buildParticipantTile(ParticipantInfo participant, {bool isHost = false}) {
//     final displayName = participant.name.isNotEmpty ? participant.name : 'User ${participant.uid}';
//     final firstChar = displayName.isNotEmpty ? displayName[0].toUpperCase() : 'U';
//
//     return Container(
//       decoration: BoxDecoration(
//         color: Colors.grey[900],
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(
//           color: isHost ? Colors.red[700]! : Colors.grey[700]!,
//           width: 2,
//         ),
//       ),
//       child: Stack(
//         children: [
//           // Video Stream
//           if (participant.videoEnabled && !participant.isScreenSharing)
//             AgoraVideoView(
//               controller: VideoViewController(
//                 rtcEngine: _viewModel.agoraService.engine,
//                 canvas: VideoCanvas(uid: participant.uid),
//               ),
//             )
//           else if (participant.isScreenSharing)
//             AgoraVideoView(
//               controller: VideoViewController(
//                 rtcEngine: _viewModel.agoraService.engine,
//                 canvas: VideoCanvas(uid: participant.uid),
//               ),
//             )
//           else
//           // Avatar when video is off
//             Container(
//               color: isHost ? Colors.grey[800] : Colors.grey[900],
//               child: Center(
//                 child: Container(
//                   width: isHost ? 80 : 40,
//                   height: isHost ? 80 : 40,
//                   decoration: BoxDecoration(
//                     color: isHost ? Colors.red[700] : Colors.green[600],
//                     shape: BoxShape.circle,
//                   ),
//                   child: Center(
//                     child: Text(
//                       firstChar,
//                       style: TextStyle(
//                         color: Colors.white,
//                         fontSize: isHost ? 32 : 20,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//
//           // Participant info overlay
//           Positioned(
//             bottom: 4,
//             left: 4,
//             right: 4,
//             child: Container(
//               padding: EdgeInsets.symmetric(horizontal: 6, vertical: 3),
//               decoration: BoxDecoration(
//                 color: Colors.black54,
//                 borderRadius: BorderRadius.circular(6),
//               ),
//               child: Row(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   Expanded(
//                     child: Text(
//                       '${isHost ? 'Host: ' : ''}$displayName${participant.isLocal ? ' (You)' : ''}',
//                       style: TextStyle(
//                         color: Colors.white,
//                         fontSize: 10,
//                         fontWeight: FontWeight.bold,
//                       ),
//                       overflow: TextOverflow.ellipsis,
//                     ),
//                   ),
//                   if (participant.isScreenSharing)
//                     Icon(Icons.screen_share, color: Colors.green, size: 10),
//                 ],
//               ),
//             ),
//           ),
//
//           // Audio status
//           if (!participant.audioEnabled)
//             Positioned(
//               top: 4,
//               right: 4,
//               child: Container(
//                 padding: EdgeInsets.all(3),
//                 decoration: BoxDecoration(
//                   color: Colors.red[600],
//                   shape: BoxShape.circle,
//                 ),
//                 child: Icon(Icons.mic_off, color: Colors.white, size: 12),
//               ),
//             ),
//
//           // Screen sharing indicator for host
//           if (participant.isScreenSharing && isHost)
//             Positioned(
//               top: 8,
//               left: 8,
//               child: Container(
//                 padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
//                 decoration: BoxDecoration(
//                   color: Colors.green[600],
//                   borderRadius: BorderRadius.circular(8),
//                 ),
//                 child: Text(
//                   'Screen Sharing',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 10,
//                     fontWeight: FontWeight.bold,
//                   ),
//                 ),
//               ),
//             ),
//         ],
//       ),
//     );
//   }
//
//   Widget _buildControls() {
//     return Positioned(
//       bottom: 0,
//       left: 0,
//       right: 0,
//       child: Container(
//         padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
//         decoration: BoxDecoration(
//           color: Colors.black.withOpacity(0.8),
//           border: Border(top: BorderSide(color: Colors.grey[800]!)),
//         ),
//         child: Row(
//           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//           children: [
//             _buildControlButton(
//               icon: _viewModel.agoraService.isAudioEnabled.value
//                   ? Icons.mic
//                   : Icons.mic_off,
//               isActive: _viewModel.agoraService.isAudioEnabled.value,
//               onPressed: _viewModel.toggleAudio,
//               label: 'Mic',
//             ),
//
//             _buildControlButton(
//               icon: _viewModel.agoraService.isVideoEnabled.value
//                   ? Icons.videocam
//                   : Icons.videocam_off,
//               isActive: _viewModel.agoraService.isVideoEnabled.value,
//               onPressed: _viewModel.canToggleVideo ? _viewModel.toggleVideo : null,
//               label: 'Camera',
//             ),
//
//             _buildControlButton(
//               icon: Icons.screen_share,
//               isActive: _viewModel.agoraService.isScreenSharing.value,
//               onPressed: _viewModel.canScreenShare ? _viewModel.toggleScreenShare : null,
//               label: 'Share',
//             ),
//
//             Obx(() => _buildControlButton(
//               icon: Icons.people,
//               isActive: _viewModel.showParticipants.value,
//               onPressed: _viewModel.toggleParticipantsPanel,
//               label: 'People',
//               badge: _viewModel.participants.length,
//             )),
//
//             Obx(() => _buildControlButton(
//               icon: Icons.chat,
//               isActive: _viewModel.showChat.value,
//               onPressed: _viewModel.toggleChatPanel,
//               label: 'Chat',
//               badge: _viewModel.unreadCount.value,
//             )),
//
//             _buildControlButton(
//               icon: Icons.call_end,
//               isActive: false,
//               onPressed: () {
//                 _viewModel.leaveSession();
//                 Get.back();
//               },
//               label: 'Leave',
//               backgroundColor: Colors.red[700]!,
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget _buildControlButton({
//     required IconData icon,
//     required bool isActive,
//     required VoidCallback? onPressed,
//     required String label,
//     int? badge,
//     Color backgroundColor = Colors.grey,
//   }) {
//     return Column(
//       mainAxisSize: MainAxisSize.min,
//       children: [
//         Container(
//           width: 50,
//           height: 50,
//           child: Stack(
//             children: [
//               Container(
//                 decoration: BoxDecoration(
//                   color: isActive ? Colors.white : backgroundColor,
//                   border: isActive ? Border.all(color: backgroundColor, width: 2) : null,
//                   borderRadius: BorderRadius.circular(25),
//                 ),
//                 child: IconButton(
//                   icon: Icon(icon,
//                       color: isActive ? backgroundColor : Colors.white, size: 20),
//                   onPressed: onPressed,
//                   padding: EdgeInsets.zero,
//                 ),
//               ),
//               if (badge != null && badge > 0)
//                 Positioned(
//                   top: 0,
//                   right: 0,
//                   child: Container(
//                     width: 18,
//                     height: 18,
//                     decoration: BoxDecoration(
//                       color: Colors.white,
//                       border: Border.all(color: backgroundColor, width: 1.5),
//                       shape: BoxShape.circle,
//                     ),
//                     child: Center(
//                       child: Text(
//                         badge > 9 ? '9+' : badge.toString(),
//                         style: TextStyle(
//                           color: backgroundColor,
//                           fontSize: 8,
//                           fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//             ],
//           ),
//         ),
//         SizedBox(height: 4),
//         Text(
//           label,
//           style: TextStyle(
//             color: Colors.white,
//             fontSize: 10,
//           ),
//         ),
//       ],
//     );
//   }
//
//   Widget _buildSidePanels() {
//     return Obx(() {
//       return Row(
//         children: [
//           if (_viewModel.showParticipants.value)
//             _buildParticipantsPanel(),
//
//           if (_viewModel.showChat.value)
//             _buildChatPanel(),
//         ],
//       );
//     });
//   }
//
//   Widget _buildParticipantsPanel() {
//     return Container(
//       width: 300,
//       margin: EdgeInsets.only(
//         top: MediaQuery.of(context).padding.top + 60,
//         bottom: 80,
//         right: 8,
//       ),
//       decoration: BoxDecoration(
//         color: Colors.black.withOpacity(0.9),
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(color: Colors.grey[700]!),
//       ),
//       child: Column(
//         children: [
//           Container(
//             padding: EdgeInsets.all(16),
//             decoration: BoxDecoration(
//               color: Colors.red[700],
//               borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
//             ),
//             child: Row(
//               children: [
//                 Obx(() => Text(
//                   'Participants (${_viewModel.participants.length})',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 16,
//                     fontWeight: FontWeight.bold,
//                   ),
//                 )),
//                 Spacer(),
//                 IconButton(
//                   icon: Icon(Icons.close, color: Colors.white, size: 20),
//                   onPressed: _viewModel.toggleParticipantsPanel,
//                 ),
//               ],
//             ),
//           ),
//           Expanded(
//             child: Obx(() {
//               final participants = _viewModel.participants;
//               if (participants.isEmpty) {
//                 return Center(
//                   child: Text(
//                     'No participants',
//                     style: TextStyle(color: Colors.white70),
//                   ),
//                 );
//               }
//               return ListView.builder(
//                 padding: EdgeInsets.all(8),
//                 itemCount: participants.length,
//                 itemBuilder: (context, index) {
//                   final participant = participants[index];
//                   return _buildParticipantListItem(participant);
//                 },
//               );
//             }),
//           ),
//         ],
//       ),
//     );
//   }
//
//   Widget _buildParticipantListItem(ParticipantInfo participant) {
//     final displayName = participant.name.isNotEmpty ? participant.name : 'User ${participant.uid}';
//     final firstChar = displayName.isNotEmpty ? displayName[0].toUpperCase() : 'U';
//
//     return Container(
//       margin: EdgeInsets.only(bottom: 8),
//       padding: EdgeInsets.all(12),
//       decoration: BoxDecoration(
//         color: Colors.grey[900],
//         borderRadius: BorderRadius.circular(8),
//         border: Border.all(color: Colors.grey[700]!),
//       ),
//       child: Row(
//         children: [
//           Container(
//             width: 40,
//             height: 40,
//             decoration: BoxDecoration(
//               color: participant.isLocal ? Colors.red[700] : Colors.green[600],
//               shape: BoxShape.circle,
//             ),
//             child: Center(
//               child: Text(
//                 firstChar,
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ),
//           ),
//           SizedBox(width: 12),
//           Expanded(
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Text(
//                   '$displayName ${participant.isLocal ? '(You)' : ''}',
//                   style: TextStyle(
//                     fontWeight: FontWeight.bold,
//                     color: Colors.white,
//                   ),
//                 ),
//                 Text(
//                   '${participant.audioEnabled ? 'Audio on' : 'Audio off'} • ${participant.videoEnabled ? 'Video on' : 'Video off'}',
//                   style: TextStyle(
//                     fontSize: 12,
//                     color: Colors.grey[400],
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           Row(
//             children: [
//               Icon(
//                 participant.audioEnabled ? Icons.mic : Icons.mic_off,
//                 color: participant.audioEnabled ? Colors.green[400] : Colors.red[400],
//                 size: 16,
//               ),
//               SizedBox(width: 4),
//               Icon(
//                 participant.videoEnabled ? Icons.videocam : Icons.videocam_off,
//                 color: participant.videoEnabled ? Colors.green[400] : Colors.red[400],
//                 size: 16,
//               ),
//             ],
//           ),
//         ],
//       ),
//     );
//   }
//
//   Widget _buildChatPanel() {
//     return Container(
//       width: 300,
//       margin: EdgeInsets.only(
//         top: MediaQuery.of(context).padding.top + 60,
//         bottom: 80,
//         right: 8,
//       ),
//       decoration: BoxDecoration(
//         color: Colors.black.withOpacity(0.9),
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(color: Colors.grey[700]!),
//       ),
//       child: Column(
//         children: [
//           Container(
//             padding: EdgeInsets.all(16),
//             decoration: BoxDecoration(
//               color: Colors.red[700],
//               borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
//             ),
//             child: Row(
//               children: [
//                 Text(
//                   'Chat',
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 16,
//                     fontWeight: FontWeight.bold,
//                   ),
//                 ),
//                 Spacer(),
//                 IconButton(
//                   icon: Icon(Icons.close, color: Colors.white, size: 20),
//                   onPressed: _viewModel.toggleChatPanel,
//                 ),
//               ],
//             ),
//           ),
//           Expanded(
//             child: Obx(() {
//               return ListView.builder(
//                 padding: EdgeInsets.all(8),
//                 reverse: true,
//                 itemCount: _viewModel.messages.length,
//                 itemBuilder: (context, index) {
//                   final message = _viewModel.messages.reversed.toList()[index];
//                   return _buildMessageBubble(message);
//                 },
//               );
//             }),
//           ),
//           Container(
//             padding: EdgeInsets.all(12),
//             decoration: BoxDecoration(
//               color: Colors.grey[900],
//               border: Border(top: BorderSide(color: Colors.grey[700]!)),
//             ),
//             child: Row(
//               children: [
//                 Expanded(
//                   child: TextField(
//                     controller: TextEditingController(text: _viewModel.newMessage.value),
//                     onChanged: (value) => _viewModel.newMessage.value = value,
//                     style: TextStyle(color: Colors.white),
//                     decoration: InputDecoration(
//                       hintText: 'Type a message...',
//                       hintStyle: TextStyle(color: Colors.grey[500]),
//                       border: OutlineInputBorder(
//                         borderRadius: BorderRadius.circular(20),
//                         borderSide: BorderSide(color: Colors.grey[700]!),
//                       ),
//                       contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
//                       filled: true,
//                       fillColor: Colors.grey[800],
//                     ),
//                     onSubmitted: (value) {
//                       if (value.trim().isNotEmpty) {
//                         _viewModel.sendMessage(value);
//                       }
//                     },
//                   ),
//                 ),
//                 SizedBox(width: 8),
//                 Container(
//                   decoration: BoxDecoration(
//                     color: Colors.red[700],
//                     shape: BoxShape.circle,
//                   ),
//                   child: IconButton(
//                     icon: Icon(Icons.send, color: Colors.white, size: 20),
//                     onPressed: () {
//                       if (_viewModel.newMessage.value.trim().isNotEmpty) {
//                         _viewModel.sendMessage(_viewModel.newMessage.value);
//                       }
//                     },
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
//
//   Widget _buildMessageBubble(ChatMessage message) {
//     final isSystem = message.type == MessageType.system;
//     final isLocalUser = message.senderId == _viewModel.agoraService.localUserId;
//
//     if (isSystem) {
//       return Container(
//         padding: EdgeInsets.symmetric(vertical: 4),
//         child: Text(
//           message.message,
//           textAlign: TextAlign.center,
//           style: TextStyle(
//             color: Colors.grey[500],
//             fontSize: 12,
//             fontStyle: FontStyle.italic,
//           ),
//         ),
//       );
//     }
//
//     final senderName = message.senderName.isNotEmpty ? message.senderName : 'User';
//     final firstChar = senderName.isNotEmpty ? senderName[0].toUpperCase() : 'U';
//
//     return Container(
//       margin: EdgeInsets.symmetric(vertical: 4),
//       child: Row(
//         mainAxisAlignment: isLocalUser ? MainAxisAlignment.end : MainAxisAlignment.start,
//         children: [
//           if (!isLocalUser)
//             Container(
//               width: 32,
//               height: 32,
//               decoration: BoxDecoration(
//                 color: Colors.red[700],
//                 shape: BoxShape.circle,
//               ),
//               child: Center(
//                 child: Text(
//                   firstChar,
//                   style: TextStyle(
//                     color: Colors.white,
//                     fontSize: 12,
//                     fontWeight: FontWeight.bold,
//                   ),
//                 ),
//               ),
//             ),
//           SizedBox(width: 8),
//           Flexible(
//             child: Container(
//               padding: EdgeInsets.all(12),
//               decoration: BoxDecoration(
//                 color: isLocalUser ? Colors.red[700] : Colors.grey[800],
//                 borderRadius: BorderRadius.only(
//                   topLeft: Radius.circular(16),
//                   topRight: Radius.circular(16),
//                   bottomLeft: isLocalUser ? Radius.circular(16) : Radius.circular(4),
//                   bottomRight: isLocalUser ? Radius.circular(4) : Radius.circular(16),
//                 ),
//               ),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   if (!isLocalUser)
//                     Text(
//                       senderName,
//                       style: TextStyle(
//                         color: Colors.white,
//                         fontSize: 12,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),
//                   Text(
//                     message.message,
//                     style: TextStyle(color: Colors.white),
//                   ),
//                   SizedBox(height: 4),
//                   Text(
//                     '${message.timestamp.hour}:${message.timestamp.minute.toString().padLeft(2, '0')}',
//                     style: TextStyle(
//                       color: Colors.white70,
//                       fontSize: 10,
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }