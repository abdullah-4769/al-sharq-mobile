import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../services/live_streaming_services/agora_services.dart';

class AgoraViewModel extends GetxController {
  final AgoraService _agoraService = Get.find<AgoraService>();

  final RxBool isLoading = false.obs;
  final RxString errorMessage = ''.obs;
  final RxString currentChannel = ''.obs;
  final RxString userDisplayName = ''.obs;
  final RxString userRole = 'audience'.obs;

  // Chat
  final RxList<ChatMessage> messages = <ChatMessage>[].obs;
  final TextEditingController chatController = TextEditingController();
  final RxInt unreadCount = 0.obs;
  final RxBool showChat = false.obs;

  // Participants
  final RxBool showParticipants = false.obs;
  final RxString viewMode = 'grid'.obs;
  final Rx<ParticipantInfo?> selectedSpeaker = Rx<ParticipantInfo?>(null);

  // REACTIVE PARTICIPANTS LIST
  final RxList<ParticipantInfo> participantsRx = <ParticipantInfo>[].obs;

  // CRITICAL: Force UI rebuild trigger
  final RxInt renderTrigger = 0.obs;

  AgoraService get agoraService => _agoraService;
// In AgoraViewModel - Make sure this getter exists
  bool get isJoined => _agoraService.isJoined.value;
  bool get isHost => userRole.value == 'host';

// // Add this method for debugging
//   void checkVideoStatus() {
//     debugPrint('=== VIDEO STATUS CHECK ===');
//     debugPrint('isJoined: $isJoined');
//     debugPrint('isLoading: ${isLoading.value}');
//     debugPrint('Local User ID: ${_agoraService.localUserId}');
//     debugPrint('Video Enabled: ${_agoraService.isVideoEnabled.value}');
//     debugPrint('Audio Enabled: ${_agoraService.isAudioEnabled.value}');
//     debugPrint('Participants Count: ${participants.length}');
//
//     for (final participant in participants) {
//       debugPrint('Participant ${participant.uid}: '
//           'Name: ${participant.name}, '
//           'Local: ${participant.isLocal}, '
//           'Video: ${participant.videoEnabled}, '
//           'Audio: ${participant.audioEnabled}');
//     }
//   }
  @override
  void onInit() {
    super.onInit();
    debugPrint('=== AgoraViewModel initialized ===');

    // Auto-refresh participants on any change
    ever(_agoraService.isJoined, (_) {
      refreshParticipants();
      renderTrigger.value++; // Force UI rebuild
    });
    ever(_agoraService.isAudioEnabled, (_) => refreshParticipants());
    ever(_agoraService.isVideoEnabled, (_) {
      refreshParticipants();
      renderTrigger.value++; // Force UI rebuild
    });
    ever(_agoraService.isScreenSharing, (_) => refreshParticipants());
    ever(_agoraService.remoteUsers, (_) {
      refreshParticipants();
      renderTrigger.value++; // Force UI rebuild
    });
    ever(_agoraService.userStates, (_) => refreshParticipants());
  }

  void refreshParticipants() {
    final list = <ParticipantInfo>[];

    if (_agoraService.isJoined.value) {
      list.add(ParticipantInfo(
        uid: _agoraService.localUserId,
        name: userDisplayName.value,
        isLocal: true,
        isHost: isHost,
        audioEnabled: _agoraService.isAudioEnabled.value,
        videoEnabled: _agoraService.isVideoEnabled.value || _agoraService.isScreenSharing.value,
        isScreenSharing: _agoraService.isScreenSharing.value,
      ));
    }

    for (final uid in _agoraService.remoteUserIds) {
      final state = _agoraService.userStates[uid];
      final user = _agoraService.remoteUsers[uid];
      list.add(ParticipantInfo(
        uid: uid,
        name: user?.name ?? 'User $uid',
        isLocal: false,
        isHost: false,
        audioEnabled: state?.hasAudio ?? false,
        videoEnabled: state?.hasVideo ?? false,
        isScreenSharing: false,
      ));
    }

    participantsRx.assignAll(list);
  }

  List<ParticipantInfo> get participants => participantsRx;

// In AgoraViewModel - ADD THESE CRITICAL FIXES


// Update the joinSession method to ensure proper state
  Future<bool> joinSession({
    required int sessionId,
    required String nickname,
    required String sessionTitle,
    required String token,
    required int userId,
    String role = 'audience',
  }) async {
    try {
      debugPrint('=== Joining session: $sessionId as $role ===');

      // Reset state
      isLoading.value = true;
      errorMessage.value = '';

      // Ensure we're not already joined
      if (_agoraService.isJoined.value) {
        await leaveSession();
        await Future.delayed(const Duration(milliseconds: 1000));
      }

      userRole.value = role;
      userDisplayName.value = nickname.isNotEmpty ? nickname : 'User $userId';

      final agoraRole = role == 'host'
          ? ClientRoleType.clientRoleBroadcaster
          : ClientRoleType.clientRoleAudience;

      final channelName = _cleanChannelName(sessionTitle);

      await _agoraService.joinChannel(
        token: token,
        channelName: channelName,
        uid: userId,
        role: agoraRole,
      );

      currentChannel.value = channelName;

      // Wait for connection
      await Future.delayed(const Duration(milliseconds: 2000));

      // Force refresh
      refreshParticipants();
      renderTrigger.value++;

      return true;
    } catch (e) {
      errorMessage.value = 'Failed to join: $e';
      debugPrint('=== Error joining session: $e ===');
      return false;
    } finally {
      isLoading.value = false;
    }
  }



// And add the debug method
  void checkVideoStatus() {
    debugPrint('=== VIDEO STATUS CHECK ===');
    debugPrint('isJoined: $isJoined');
    debugPrint('isLoading: ${isLoading.value}');
    debugPrint('Local User ID: ${_agoraService.localUserId}');
    debugPrint('Video Enabled: ${_agoraService.isVideoEnabled.value}');
    debugPrint('Audio Enabled: ${_agoraService.isAudioEnabled.value}');
    debugPrint('Participants Count: ${participants.length}');

    for (final participant in participants) {
      debugPrint('Participant ${participant.uid}: '
          'Name: ${participant.name}, '
          'Local: ${participant.isLocal}, '
          'Video: ${participant.videoEnabled}, '
          'Audio: ${participant.audioEnabled}');
    }
  }

  String _cleanChannelName(String name) {
    return name
        .replaceAll(RegExp(r'[^\w]'), '_')
        .replaceAll(RegExp(r'_+'), '_')
        .toLowerCase()
        .substring(0, name.length > 64 ? 64 : name.length);
  }

  Future<void> leaveSession() async {
    try {
      await _agoraService.leaveChannel();
      currentChannel.value = '';
      userDisplayName.value = '';
      userRole.value = 'audience';
      messages.clear();
      unreadCount.value = 0;
      showChat.value = false;
      showParticipants.value = false;
      selectedSpeaker.value = null;
      participantsRx.clear();
      renderTrigger.value = 0;
    } catch (e) {
      debugPrint('=== Error leaving session: $e ===');
    }
  }

  Future<void> toggleAudio() async {
    await _agoraService.toggleAudio();
    addSystemMessage('${userDisplayName.value} ${_agoraService.isAudioEnabled.value ? "unmuted" : "muted"} mic');
  }

  Future<void> toggleVideo() async {
    await _agoraService.toggleVideo();
    addSystemMessage('${userDisplayName.value} ${_agoraService.isVideoEnabled.value ? "started" : "stopped"} video');
    renderTrigger.value++;
  }

  Future<void> toggleScreenShare() async {
    if (_agoraService.isScreenSharing.value) {
      await _agoraService.stopScreenSharing();
      addSystemMessage('Screen sharing stopped');
    } else {
      await _agoraService.startScreenSharing();
      addSystemMessage('Screen sharing started');
    }
    renderTrigger.value++;
  }

  Future<void> switchCamera() async => await _agoraService.switchCamera();

  void sendMessage() {
    final text = chatController.text.trim();
    if (text.isEmpty) return;

    messages.add(ChatMessage(
      senderId: _agoraService.localUserId,
      senderName: userDisplayName.value,
      message: text,
      timestamp: DateTime.now(),
      type: MessageType.user,
      isHost: isHost,
    ));
    chatController.clear();
    if (!showChat.value) unreadCount.value++;
  }

  void addSystemMessage(String text) {
    messages.add(ChatMessage(
      senderId: 0,
      senderName: 'System',
      message: text,
      timestamp: DateTime.now(),
      type: MessageType.system,
      isHost: false,
    ));
  }

  void toggleChatPanel() {
    showChat.value = !showChat.value;
    if (showChat.value) {
      unreadCount.value = 0;
      showParticipants.value = false;
    }
  }

  void toggleParticipantsPanel() {
    showParticipants.value = !showParticipants.value;
    if (showParticipants.value) showChat.value = false;
  }

  void switchViewMode() {
    viewMode.value = viewMode.value == 'grid' ? 'speaker' : 'grid';
  }

  void selectSpeaker(ParticipantInfo p) => selectedSpeaker.value = p;

  Future<void> muteUserAudio(int uid) async => addSystemMessage('Muted audio for user $uid');
  Future<void> muteUserVideo(int uid) async => addSystemMessage('Muted video for user $uid');
  Future<void> removeUser(int uid) async => addSystemMessage('Removed user $uid');

  bool get canToggleVideo => isJoined && isHost && !_agoraService.isScreenSharing.value;
  bool get canScreenShare => isJoined && isHost;
  bool get canSwitchCamera => isJoined && isHost && _agoraService.isVideoEnabled.value;
}

class ChatMessage {
  final int senderId;
  final String senderName;
  final String message;
  final DateTime timestamp;
  final MessageType type;
  final bool isHost;

  ChatMessage({
    required this.senderId,
    required this.senderName,
    required this.message,
    required this.timestamp,
    required this.type,
    required this.isHost,
  });
}

enum MessageType { user, system }

class ParticipantInfo {
  final int uid;
  final String name;
  final bool isLocal;
  final bool isHost;
  final bool audioEnabled;
  final bool videoEnabled;
  final bool isScreenSharing;

  ParticipantInfo({
    required this.uid,
    required this.name,
    required this.isLocal,
    required this.isHost,
    required this.audioEnabled,
    required this.videoEnabled,
    required this.isScreenSharing,
  });

  String get displayName => '$name${isLocal ? " (You)" : ""}${isHost ? " [Host]" : ""}';
  String get firstChar => name.isNotEmpty ? name[0].toUpperCase() : 'U';
}

// import 'package:agora_rtc_engine/agora_rtc_engine.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
//
// import '../../services/live_streaming_services/agora_services.dart';
//
// class AgoraViewModel extends GetxController {
//   final AgoraService _agoraService = Get.find<AgoraService>();
//
//   final RxBool isLoading = false.obs;
//   final RxString errorMessage = ''.obs;
//   final RxString currentChannel = ''.obs;
//   final RxString userDisplayName = ''.obs;
//   final RxString userRole = 'audience'.obs; // 'host' or 'audience'
//
//   // Chat functionality
//   final RxList<ChatMessage> messages = <ChatMessage>[].obs;
//   final TextEditingController chatController = TextEditingController();
//   final RxInt unreadCount = 0.obs;
//   final RxBool showChat = false.obs;
//
//   // Participants functionality
//   final RxBool showParticipants = false.obs;
//   final RxString viewMode = 'grid'.obs; // 'grid' or 'speaker'
//
//   // Selected speaker for speaker view
//   final Rx<ParticipantInfo?> selectedSpeaker = Rx<ParticipantInfo?>(null);
//
//   AgoraService get agoraService => _agoraService;
//
//   @override
//   void onInit() {
//     super.onInit();
//     debugPrint('=== AgoraViewModel initialized ===');
//   }
//
//   @override
//   void onClose() {
//     leaveSession();
//     chatController.dispose();
//     super.onClose();
//   }
//
//   Future<bool> joinSession({
//     required int sessionId,
//     required String nickname,
//     required String sessionTitle,
//     required String token,
//     required int userId,
//     String role = 'audience',
//   }) async {
//     try {
//       debugPrint('=== Joining session: $sessionId as $role ===');
//
//       if (_agoraService.isJoined.value) {
//         debugPrint('=== Already in a channel, leaving first ===');
//         await leaveSession();
//         await Future.delayed(const Duration(seconds: 1));
//       }
//
//       isLoading.value = true;
//       errorMessage.value = '';
//
//       userRole.value = role;
//       final agoraRole = role == 'host'
//           ? ClientRoleType.clientRoleBroadcaster
//           : ClientRoleType.clientRoleAudience;
//
//       final channelName = _cleanChannelName(sessionTitle);
//       debugPrint('=== Cleaned channel: $channelName, Role: $agoraRole ===');
//
//       await _agoraService.joinChannel(
//         token: token,
//         channelName: channelName,
//         uid: userId,
//         role: agoraRole,
//       );
//
//       currentChannel.value = channelName;
//       userDisplayName.value = nickname.isNotEmpty ? nickname : 'User $userId';
//
//       addSystemMessage('${userDisplayName.value} joined the session');
//
//       debugPrint('=== Session joined successfully ===');
//       return true;
//     } catch (e) {
//       errorMessage.value = 'Failed to join: $e';
//       debugPrint('=== Error joining session: $e ===');
//       return false;
//     } finally {
//       isLoading.value = false;
//     }
//   }
//
//   String _cleanChannelName(String channelName) {
//     return channelName
//         .replaceAll(RegExp(r'[^\w]'), '_')
//         .replaceAll(RegExp(r'_+'), '_')
//         .toLowerCase()
//         .substring(0, channelName.length > 64 ? 64 : null);
//   }
//
//   Future<void> leaveSession() async {
//     try {
//       debugPrint('=== Leaving session ===');
//       await _agoraService.leaveChannel();
//
//       currentChannel.value = '';
//       userDisplayName.value = '';
//       userRole.value = 'audience';
//       messages.clear();
//       unreadCount.value = 0;
//       showChat.value = false;
//       showParticipants.value = false;
//       selectedSpeaker.value = null;
//
//       debugPrint('=== Session left successfully ===');
//     } catch (e) {
//       debugPrint('=== Error leaving session: $e ===');
//     }
//   }
//
//   // Media controls
//   Future<void> toggleAudio() async {
//     await _agoraService.toggleAudio();
//     addSystemMessage('${userDisplayName.value} ${_agoraService.isAudioEnabled.value ? "unmuted" : "muted"} microphone');
//   }
//
//   Future<void> toggleVideo() async {
//     await _agoraService.toggleVideo();
//     addSystemMessage('${userDisplayName.value} ${_agoraService.isVideoEnabled.value ? "started" : "stopped"} video');
//   }
//
//   Future<void> toggleScreenShare() async {
//     if (_agoraService.isScreenSharing.value) {
//       await _agoraService.stopScreenSharing();
//       addSystemMessage('Screen sharing stopped');
//     } else {
//       await _agoraService.startScreenSharing();
//       addSystemMessage('Screen sharing started');
//     }
//   }
//
//   Future<void> switchCamera() async {
//     await _agoraService.switchCamera();
//   }
//
//   // Chat methods
//   void sendMessage() {
//     final message = chatController.text.trim();
//     if (message.isEmpty) return;
//
//     debugPrint('=== Sending message: $message ===');
//
//     final chatMessage = ChatMessage(
//       senderId: _agoraService.localUserId,
//       senderName: userDisplayName.value,
//       message: message,
//       timestamp: DateTime.now(),
//       type: MessageType.user,
//       isHost: isHost, // Added isHost property
//     );
//
//     messages.add(chatMessage);
//     chatController.clear();
//
//     if (!showChat.value) {
//       unreadCount.value++;
//     }
//   }
//
//   void addSystemMessage(String text) {
//     final systemMessage = ChatMessage(
//       senderId: 0,
//       senderName: 'System',
//       message: text,
//       timestamp: DateTime.now(),
//       type: MessageType.system,
//       isHost: false, // System messages are not from host
//     );
//     messages.add(systemMessage);
//   }
//
//   void toggleChatPanel() {
//     showChat.value = !showChat.value;
//     if (showChat.value) {
//       unreadCount.value = 0;
//       showParticipants.value = false;
//     }
//   }
//
//   void toggleParticipantsPanel() {
//     showParticipants.value = !showParticipants.value;
//     if (showParticipants.value) {
//       showChat.value = false;
//     }
//   }
//
//   void switchViewMode() {
//     viewMode.value = viewMode.value == 'grid' ? 'speaker' : 'grid';
//     debugPrint('=== View mode: ${viewMode.value} ===');
//   }
//
//   void selectSpeaker(ParticipantInfo participant) {
//     selectedSpeaker.value = participant;
//     debugPrint('=== Selected speaker: ${participant.name} ===');
//   }
//
//   // Host controls for managing participants
//   Future<void> muteUserAudio(int uid) async {
//     try {
//       debugPrint('=== Muting user audio: $uid ===');
//       // Implement audio muting logic for remote users
//       // This would typically involve sending a signal to the user or using Agora's admin capabilities
//       addSystemMessage('Audio muted for user $uid');
//     } catch (e) {
//       debugPrint('=== Error muting user audio: $e ===');
//     }
//   }
//
//   Future<void> muteUserVideo(int uid) async {
//     try {
//       debugPrint('=== Muting user video: $uid ===');
//       // Implement video muting logic for remote users
//       // This would typically involve sending a signal to the user or using Agora's admin capabilities
//       addSystemMessage('Video muted for user $uid');
//     } catch (e) {
//       debugPrint('=== Error muting user video: $e ===');
//     }
//   }
//
//   Future<void> removeUser(int uid) async {
//     try {
//       debugPrint('=== Removing user: $uid ===');
//       // Implement user removal logic
//       // This would typically involve sending a signal to kick the user from the channel
//       addSystemMessage('User $uid removed from session');
//     } catch (e) {
//       debugPrint('=== Error removing user: $e ===');
//     }
//   }
//
//   // Getters
//   bool get isJoined => _agoraService.isJoined.value;
//   bool get isHost => userRole.value == 'host';
//
//   bool get canToggleVideo =>
//       isJoined && isHost && !_agoraService.isScreenSharing.value;
//
//   bool get canScreenShare => isJoined && isHost;
//
//   bool get canSwitchCamera =>
//       isJoined && isHost && _agoraService.isVideoEnabled.value;
//
//   List<ParticipantInfo> get participants {
//     final participants = <ParticipantInfo>[];
//
//     // Add local user if joined
//     if (_agoraService.isJoined.value) {
//       participants.add(ParticipantInfo(
//         uid: _agoraService.localUserId,
//         name: userDisplayName.value,
//         isLocal: true,
//         isHost: isHost,
//         audioEnabled: _agoraService.isAudioEnabled.value,
//         videoEnabled: _agoraService.isVideoEnabled.value || _agoraService.isScreenSharing.value,
//         isScreenSharing: _agoraService.isScreenSharing.value,
//       ));
//     }
//
//     // Add remote users
//     for (final remoteUid in _agoraService.remoteUserIds) {
//       final userState = _agoraService.userStates[remoteUid];
//       final remoteUser = _agoraService.remoteUsers[remoteUid];
//
//       participants.add(ParticipantInfo(
//         uid: remoteUid,
//         name: remoteUser?.name ?? 'User $remoteUid',
//         isLocal: false,
//         isHost: false,
//         audioEnabled: userState?.hasAudio ?? false,
//         videoEnabled: userState?.hasVideo ?? false,
//         isScreenSharing: false,
//       ));
//     }
//
//     return participants;
//   }
// }
//
// // Data models
// class ChatMessage {
//   final int senderId;
//   final String senderName;
//   final String message;
//   final DateTime timestamp;
//   final MessageType type;
//   final bool isHost; // Added isHost property
//
//   ChatMessage({
//     required this.senderId,
//     required this.senderName,
//     required this.message,
//     required this.timestamp,
//     required this.type,
//     required this.isHost, // Added isHost parameter
//   });
// }
//
// enum MessageType { user, system }
//
// class ParticipantInfo {
//   final int uid;
//   final String name;
//   final bool isLocal;
//   final bool isHost;
//   final bool audioEnabled;
//   final bool videoEnabled;
//   final bool isScreenSharing;
//
//   ParticipantInfo({
//     required this.uid,
//     required this.name,
//     required this.isLocal,
//     required this.isHost,
//     required this.audioEnabled,
//     required this.videoEnabled,
//     required this.isScreenSharing,
//   });
//
//   String get displayName => '$name${isLocal ? " (You)" : ""}${isHost ? " 👑" : ""}';
//
//   String get firstChar => name.isNotEmpty ? name[0].toUpperCase() : 'U';
// }
// // import 'package:agora_rtc_engine/agora_rtc_engine.dart';
// // import 'package:get/get.dart';
// //
// // import '../../repository/live_streaming_repository/agora_token_repository.dart';
// // import '../../services/live_streaming_services/agora_services.dart';
// // import '../../utils/shared_preference.dart';
// //
// // class AgoraViewModel extends GetxController {
// //   final AgoraTokenRepository _tokenRepo = AgoraTokenRepository();
// //   final AgoraService _agoraService = Get.find<AgoraService>();
// //
// //   final RxBool isLoading = false.obs;
// //   final RxString errorMessage = ''.obs;
// //   final RxString currentChannel = ''.obs;
// //   final RxString userDisplayName = ''.obs;
// //
// //   // Chat functionality
// //   final RxList<ChatMessage> messages = <ChatMessage>[].obs;
// //   final RxString newMessage = ''.obs;
// //   final RxInt unreadCount = 0.obs;
// //   final RxBool showChat = false.obs;
// //
// //   // Participants functionality
// //   final RxBool showParticipants = false.obs;
// //   final RxString viewMode = 'grid'.obs; // 'grid' or 'speaker'
// //
// //   @override
// //   void onInit() {
// //     super.onInit();
// //     print('=== AgoraViewModel initialized ===');
// //   }
// //
// //   @override
// //   void onClose() {
// //     _leaveSession();
// //     super.onClose();
// //   }
// //
// //   Future<bool> joinSession({
// //     required int sessionId,
// //     required String nickname,
// //     required String sessionTitle,
// //   }) async {
// //     try {
// //       print('=== Joining session: $sessionId with nickname: $nickname, title: $sessionTitle ===');
// //
// //       // Check if already joined
// //       if (_agoraService.isJoined.value) {
// //         print('=== Already in a channel, leaving first ===');
// //         await _leaveSession();
// //         await Future.delayed(Duration(seconds: 1)); // Small delay
// //       }
// //
// //       isLoading.value = true;
// //       errorMessage.value = '';
// //
// //       final userId = await SharedPrefsHelper.getUserId();
// //       if (userId == null) {
// //         throw Exception('User ID not found');
// //       }
// //
// //       // Determine user role
// //       final userRole = await _getUserRole(sessionId);
// //       final agoraRole = userRole == 'speaker'
// //           ? ClientRoleType.clientRoleBroadcaster
// //           : ClientRoleType.clientRoleAudience;
// //
// //       print('=== User role: $userRole, Agora role: $agoraRole ===');
// //
// //       // Clean the channel name for both token and join
// //       final channelName = _cleanChannelName(sessionTitle);
// //       print('=== Cleaned channel name: $channelName ===');
// //
// //       // Generate token using cleaned channel name
// //       final token = await _tokenRepo.generateToken(
// //         channelName: channelName,
// //         uid: userId,
// //         role: userRole,
// //       );
// //
// //       print('=== Token generated, joining channel... ===');
// //
// //       // Join channel with the SAME cleaned channel name
// //       await _agoraService.joinChannel(
// //         token: token,
// //         channelName: channelName,
// //         uid: userId,
// //         role: agoraRole,
// //       );
// //
// //       currentChannel.value = channelName;
// //       userDisplayName.value = nickname;
// //
// //       // Save user info for chat
// //       _saveUserInfo(userId, nickname);
// //
// //       print('=== Session joined successfully ===');
// //       return true;
// //     } catch (e) {
// //       errorMessage.value = 'Failed to join session: $e';
// //       print('=== Error joining session: $e ===');
// //       return false;
// //     } finally {
// //       isLoading.value = false;
// //     }
// //   }
// //   // ADD THIS METHOD - It was missing
// //   String _cleanChannelName(String channelName) {
// //     return channelName
// //         .replaceAll(RegExp(r'[^\w]'), '_') // Replace non-word characters with underscore
// //         .replaceAll(RegExp(r'_+'), '_') // Replace multiple underscores with single
// //         .toLowerCase();
// //   }
// //   // Future<bool> joinSession({
// //   //   required int sessionId,
// //   //   required String nickname,
// //   //   required String sessionTitle,
// //   // }) async {
// //   //   try {
// //   //     print('=== Joining session: $sessionId with nickname: $nickname, title: $sessionTitle ===');
// //   //     isLoading.value = true;
// //   //     errorMessage.value = '';
// //   //
// //   //     final userId = await SharedPrefsHelper.getUserId();
// //   //     if (userId == null) {
// //   //       throw Exception('User ID not found');
// //   //     }
// //   //
// //   //     // Determine user role
// //   //     final userRole = await _getUserRole(sessionId);
// //   //     final agoraRole = userRole == 'speaker'
// //   //         ? ClientRoleType.clientRoleBroadcaster
// //   //         : ClientRoleType.clientRoleAudience;
// //   //
// //   //     print('=== User role: $userRole, Agora role: $agoraRole ===');
// //   //
// //   //     // Generate token using the actual session title
// //   //     final channelName = sessionTitle;
// //   //     final token = await _tokenRepo.generateToken(
// //   //       channelName: channelName,
// //   //       uid: userId,
// //   //       role: userRole,
// //   //     );
// //   //
// //   //     // Join channel
// //   //     await _agoraService.joinChannel(
// //   //       token: token,
// //   //       channelName: channelName,
// //   //       uid: userId,
// //   //       role: agoraRole,
// //   //     );
// //   //
// //   //     currentChannel.value = channelName;
// //   //     userDisplayName.value = nickname;
// //   //
// //   //     // Save user info for chat
// //   //     _saveUserInfo(userId, nickname);
// //   //
// //   //     print('=== Session joined successfully ===');
// //   //     return true;
// //   //   } catch (e) {
// //   //     errorMessage.value = 'Failed to join session: $e';
// //   //     print('=== Error joining session: $e ===');
// //   //     return false;
// //   //   } finally {
// //   //     isLoading.value = false;
// //   //   }
// //   // }
// //
// //   Future<String> _getUserRole(int sessionId) async {
// //     // Implement logic to determine if user is speaker or participant
// //     // For now, return 'audience' for all users
// //     // You can extend this to check user role from API
// //     return 'audience';
// //   }
// //
// //   void _saveUserInfo(int userId, String displayName) {
// //     // Save user info for chat and participant list
// //     print('=== User info saved - ID: $userId, Name: $displayName ===');
// //   }
// //
// //   Future<void> _leaveSession() async {
// //     try {
// //       print('=== Leaving session ===');
// //       await _agoraService.leaveChannel();
// //       currentChannel.value = '';
// //       userDisplayName.value = '';
// //       messages.clear();
// //       unreadCount.value = 0;
// //       print('=== Session left successfully ===');
// //     } catch (e) {
// //       print('=== Error leaving session: $e ===');
// //     }
// //   }
// //
// //   // Media control methods
// //   Future<void> toggleAudio() async {
// //     print('=== Toggling audio ===');
// //     await _agoraService.toggleAudio();
// //   }
// //
// //   Future<void> toggleVideo() async {
// //     print('=== Toggling video ===');
// //     await _agoraService.toggleVideo();
// //   }
// //
// //   Future<void> toggleScreenShare() async {
// //     if (_agoraService.isScreenSharing.value) {
// //       print('=== Stopping screen share ===');
// //       await _agoraService.stopScreenSharing();
// //     } else {
// //       print('=== Starting screen share ===');
// //       await _agoraService.startScreenSharing();
// //     }
// //   }
// //
// //   Future<void> switchCamera() async {
// //     print('=== Switching camera ===');
// //     await _agoraService.switchCamera();
// //   }
// //
// //   // Chat methods
// //   void sendMessage(String message) {
// //     if (message.trim().isEmpty) return;
// //
// //     print('=== Sending chat message: $message ===');
// //
// //     final chatMessage = ChatMessage(
// //       senderId: _agoraService.localUserId,
// //       senderName: userDisplayName.value,
// //       message: message,
// //       timestamp: DateTime.now(),
// //       type: MessageType.user,
// //     );
// //
// //     messages.add(chatMessage);
// //     newMessage.value = '';
// //
// //     // Here you can implement sending message to other participants
// //     // via Agora's data stream or your own messaging system
// //   }
// //
// //   void addSystemMessage(String text) {
// //     print('=== Adding system message: $text ===');
// //
// //     final systemMessage = ChatMessage(
// //       senderId: 0,
// //       senderName: 'System',
// //       message: text,
// //       timestamp: DateTime.now(),
// //       type: MessageType.system,
// //     );
// //
// //     messages.add(systemMessage);
// //   }
// //
// //   void toggleChatPanel() {
// //     showChat.value = !showChat.value;
// //     if (showChat.value) {
// //       unreadCount.value = 0;
// //     }
// //     print('=== Chat panel toggled: ${showChat.value} ===');
// //   }
// //
// //   void toggleParticipantsPanel() {
// //     showParticipants.value = !showParticipants.value;
// //     print('=== Participants panel toggled: ${showParticipants.value} ===');
// //   }
// //
// //   void switchViewMode() {
// //     viewMode.value = viewMode.value == 'grid' ? 'speaker' : 'grid';
// //     print('=== View mode switched: ${viewMode.value} ===');
// //   }
// //
// //   // Getters for UI
// //   bool get canToggleVideo =>
// //       _agoraService.isJoined.value &&
// //           !_agoraService.isScreenSharing.value;
// //
// //   bool get canScreenShare => _agoraService.isJoined.value;
// //
// //   bool get canSwitchCamera =>
// //       _agoraService.isJoined.value &&
// //           _agoraService.isVideoEnabled.value;
// //
// //   List<ParticipantInfo> get participants {
// //     final participants = <ParticipantInfo>[];
// //
// //     // Add local user
// //     participants.add(ParticipantInfo(
// //       uid: _agoraService.localUserId,
// //       name: userDisplayName.value,
// //       isLocal: true,
// //       audioEnabled: _agoraService.isAudioEnabled.value,
// //       videoEnabled: _agoraService.isVideoEnabled.value || _agoraService.isScreenSharing.value,
// //       isScreenSharing: _agoraService.isScreenSharing.value,
// //     ));
// //
// //     // Add remote users
// //     for (final remoteUid in _agoraService.remoteUserIds) {
// //       final userState = _agoraService.userStates[remoteUid];
// //       participants.add(ParticipantInfo(
// //         uid: remoteUid,
// //         name: 'User $remoteUid',
// //         isLocal: false,
// //         audioEnabled: userState?.hasAudio ?? false,
// //         videoEnabled: userState?.hasVideo ?? false,
// //         isScreenSharing: false,
// //       ));
// //     }
// //
// //     return participants;
// //   }
// // }
// //
// // // Data models for chat and participants
// // class ChatMessage {
// //   final int senderId;
// //   final String senderName;
// //   final String message;
// //   final DateTime timestamp;
// //   final MessageType type;
// //
// //   ChatMessage({
// //     required this.senderId,
// //     required this.senderName,
// //     required this.message,
// //     required this.timestamp,
// //     required this.type,
// //   });
// // }
// //
// // enum MessageType {
// //   user,
// //   system,
// // }
// //
// // class ParticipantInfo {
// //   final int uid;
// //   final String name;
// //   final bool isLocal;
// //   final bool audioEnabled;
// //   final bool videoEnabled;
// //   final bool isScreenSharing;
// //
// //   ParticipantInfo({
// //     required this.uid,
// //     required this.name,
// //     required this.isLocal,
// //     required this.audioEnabled,
// //     required this.videoEnabled,
// //     required this.isScreenSharing,
// //   });
// // }