import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:get/get.dart';
import 'package:flutter/foundation.dart';

import '../../view_model/live_streaming_viewmodel/agora_viewmodel.dart';

class AgoraService extends GetxService {
  static AgoraService get to => Get.find();

  late RtcEngine _agoraEngine;
  final _isInitialized = false.obs;
  final _localUserId = 0.obs;

  // Track states
  final isJoined = false.obs;
  final isAudioEnabled = true.obs;
  final isVideoEnabled = false.obs;
  final isScreenSharing = false.obs;
  final isFrontCamera = true.obs;
  final connectionState = ConnectionStateType.connectionStateDisconnected.obs;

  // Remote users management
  final remoteUsers = <int, RemoteUser>{}.obs;
  final userStates = <int, UserState>{}.obs;

  RtcEngine get engine => _agoraEngine;
  int get localUserId => _localUserId.value;
  bool get isInitialized => _isInitialized.value;

  @override
  void onInit() {
    super.onInit();
    debugPrint('=== AgoraService initialized ===');
  }

  @override
  void onClose() {
    _dispose();
    super.onClose();
  }

  Future<void> initializeAgoraEngine() async {
    try {
      if (_isInitialized.value) {
        debugPrint('=== Agora Engine already initialized ===');
        return;
      }

      debugPrint('=== Initializing Agora Engine ===');

      _agoraEngine = createAgoraRtcEngine();
      await _agoraEngine.initialize(const RtcEngineContext(
        appId: 'bc95ca12d08b4233babfb9a7803b59b7',
        channelProfile: ChannelProfileType.channelProfileLiveBroadcasting,
      ));

      _registerEventHandlers();

      await _agoraEngine.enableVideo();
      await _agoraEngine.enableAudio();

      await _agoraEngine.setVideoEncoderConfiguration(
        const VideoEncoderConfiguration(
          dimensions: VideoDimensions(width: 640, height: 360),
          frameRate: 15,
          bitrate: 1000,
          orientationMode: OrientationMode.orientationModeAdaptive,
        ),
      );

      _isInitialized.value = true;
      debugPrint('=== Agora Engine initialized successfully ===');
    } catch (e) {
      debugPrint('=== Error initializing Agora Engine: $e ===');
      rethrow;
    }
  }

  void _registerEventHandlers() {
    debugPrint('=== Registering Agora event handlers ===');

    _agoraEngine.registerEventHandler(
      RtcEngineEventHandler(
        onConnectionStateChanged: (connection, state, reason) {
          debugPrint('=== Connection state: $state, reason: $reason ===');
          connectionState.value = state;
        },

        onJoinChannelSuccess: (connection, elapsed) {
          debugPrint('=== Joined channel successfully, UID: ${connection.localUid} ===');
          isJoined.value = true;
          if (connection.localUid != null) {
            _localUserId.value = connection.localUid!;
          }
          _notifyParticipantsUpdate();
        },

        onUserJoined: (connection, remoteUid, elapsed) {
          debugPrint('=== Remote user joined: $remoteUid ===');
          remoteUsers[remoteUid] = RemoteUser(uid: remoteUid, name: 'User $remoteUid');
          userStates[remoteUid] = UserState(hasAudio: false, hasVideo: false, isOnline: true);
          _notifyParticipantsUpdate();
        },

        onUserOffline: (connection, remoteUid, reason) {
          debugPrint('=== Remote user offline: $remoteUid ===');
          remoteUsers.remove(remoteUid);
          userStates.remove(remoteUid);
          _notifyParticipantsUpdate();
        },

        onRemoteAudioStateChanged: (connection, remoteUid, state, reason, elapsed) {
          debugPrint('=== User $remoteUid audio state: $state ===');
          if (userStates.containsKey(remoteUid)) {
            userStates[remoteUid] = userStates[remoteUid]!.copyWith(
              hasAudio: state == RemoteAudioState.remoteAudioStateDecoding,
            );
            _notifyParticipantsUpdate();
          }
        },

        onRemoteVideoStateChanged: (connection, remoteUid, state, reason, elapsed) {
          debugPrint('=== User $remoteUid video state: $state ===');
          if (userStates.containsKey(remoteUid)) {
            userStates[remoteUid] = userStates[remoteUid]!.copyWith(
              hasVideo: state == RemoteVideoState.remoteVideoStateDecoding,
            );
            _notifyParticipantsUpdate();
          }
        },

        onFirstRemoteVideoFrame: (connection, remoteUid, width, height, elapsed) {
          debugPrint('=== First remote video frame from $remoteUid: ${width}x${height} ===');
          if (userStates.containsKey(remoteUid)) {
            userStates[remoteUid] = userStates[remoteUid]!.copyWith(hasVideo: true);
            _notifyParticipantsUpdate();
          }
        },

        onError: (errorCode, msg) {
          debugPrint('=== Agora error: $errorCode, $msg ===');
        },

        onLeaveChannel: (connection, stats) {
          debugPrint('=== Left channel ===');
          isJoined.value = false;
          remoteUsers.clear();
          userStates.clear();
          _notifyParticipantsUpdate();
        },

        onLocalVideoStateChanged: (source, state, reason) {
          debugPrint('=== Local video state: $state, reason: $reason ===');
        },

        onLocalAudioStateChanged: (connection, state, reason) {
          debugPrint('=== Local audio state: $state, reason: $reason ===');
        },
      ),
    );
  }

  void _notifyParticipantsUpdate() {
    if (Get.isRegistered<AgoraViewModel>()) {
      Get.find<AgoraViewModel>().refreshParticipants();
    }
  }

  Future<void> joinChannel({
    required String token,
    required String channelName,
    required int uid,
    required ClientRoleType role,
  }) async {
    try {
      debugPrint('=== Joining channel: $channelName, uid: $uid, role: $role ===');

      if (!_isInitialized.value) {
        await initializeAgoraEngine();
      }

      if (isJoined.value) {
        await leaveChannel();
        await Future.delayed(const Duration(milliseconds: 500));
      }

      _localUserId.value = uid;

      await _agoraEngine.setClientRole(role: role);

      // CRITICAL FIX: Enable video BEFORE joining for hosts
      if (role == ClientRoleType.clientRoleBroadcaster) {
        await _agoraEngine.enableVideo();
        await _agoraEngine.enableLocalVideo(true);
        await _agoraEngine.startPreview();
        isVideoEnabled.value = true;
        debugPrint('=== Video preview started BEFORE joining ===');
      }

      final options = ChannelMediaOptions(
        channelProfile: ChannelProfileType.channelProfileLiveBroadcasting,
        clientRoleType: role,
        autoSubscribeAudio: true,
        autoSubscribeVideo: true,
        publishCameraTrack: role == ClientRoleType.clientRoleBroadcaster,
        publishMicrophoneTrack: role == ClientRoleType.clientRoleBroadcaster,
      );

      await _agoraEngine.joinChannel(
        token: token,
        channelId: channelName,
        uid: uid,
        options: options,
      );

      debugPrint('=== Channel join request sent ===');
    } catch (e) {
      debugPrint('=== Error joining channel: $e ===');
      rethrow;
    }
  }

  Future<void> leaveChannel() async {
    try {
      debugPrint('=== Leaving channel ===');
      await _agoraEngine.stopPreview();
      await _agoraEngine.leaveChannel();

      isJoined.value = false;
      isVideoEnabled.value = false;
      isAudioEnabled.value = true;
      isScreenSharing.value = false;
      remoteUsers.clear();
      userStates.clear();
      debugPrint('=== Channel left successfully ===');
    } catch (e) {
      debugPrint('=== Error leaving channel: $e ===');
    }
  }

  Future<void> toggleAudio() async {
    try {
      if (!isJoined.value) return;
      final newState = !isAudioEnabled.value;
      await _agoraEngine.muteLocalAudioStream(!newState);
      await _agoraEngine.enableLocalAudio(newState);
      isAudioEnabled.value = newState;
      _notifyParticipantsUpdate();
    } catch (e) {
      debugPrint('=== Error toggling audio: $e ===');
      rethrow;
    }
  }

  Future<void> toggleVideo() async {
    try {
      if (!isJoined.value || isScreenSharing.value) return;

      final newState = !isVideoEnabled.value;
      debugPrint('=== Toggling video to $newState ===');

      if (newState) {
        await _agoraEngine.enableVideo();
        await _agoraEngine.enableLocalVideo(true);
        await _agoraEngine.muteLocalVideoStream(false);
        await _agoraEngine.startPreview();
      } else {
        await _agoraEngine.muteLocalVideoStream(true);
        await _agoraEngine.stopPreview();
      }

      isVideoEnabled.value = newState;
      _notifyParticipantsUpdate();
    } catch (e) {
      debugPrint('=== Error toggling video: $e ===');
      rethrow;
    }
  }

  Future<void> startScreenSharing() async {
    try {
      if (!isJoined.value) return;

      if (isVideoEnabled.value) {
        await _agoraEngine.muteLocalVideoStream(true);
        await _agoraEngine.stopPreview();
      }

      await _agoraEngine.startScreenCapture(
        const ScreenCaptureParameters2(captureAudio: true, captureVideo: true),
      );

      isScreenSharing.value = true;
      _notifyParticipantsUpdate();
    } catch (e) {
      debugPrint('=== Error starting screen share: $e ===');
      rethrow;
    }
  }

  Future<void> stopScreenSharing() async {
    try {
      if (!isJoined.value) return;

      await _agoraEngine.stopScreenCapture();

      if (isVideoEnabled.value) {
        await _agoraEngine.muteLocalVideoStream(false);
        await _agoraEngine.startPreview();
      }

      isScreenSharing.value = false;
      _notifyParticipantsUpdate();
    } catch (e) {
      debugPrint('=== Error stopping screen share: $e ===');
    }
  }

  Future<void> switchCamera() async {
    try {
      if (!isJoined.value || !isVideoEnabled.value) return;
      await _agoraEngine.switchCamera();
      isFrontCamera.value = !isFrontCamera.value;
    } catch (e) {
      debugPrint('=== Error switching camera: $e ===');
      rethrow;
    }
  }

  void _dispose() {
    try {
      debugPrint('=== Disposing Agora Engine ===');
      if (_isInitialized.value) {
        _agoraEngine.leaveChannel();
        _agoraEngine.release();
        _isInitialized.value = false;
      }
    } catch (e) {
      debugPrint('=== Error disposing Agora Engine: $e ===');
    }
  }

  List<int> get remoteUserIds => remoteUsers.keys.toList();
  int get totalParticipants => remoteUsers.length + (isJoined.value ? 1 : 0);
}

class RemoteUser {
  final int uid;
  final String name;
  RemoteUser({required this.uid, required this.name});
}

class UserState {
  final bool hasAudio;
  final bool hasVideo;
  final bool isOnline;

  UserState({required this.hasAudio, required this.hasVideo, required this.isOnline});

  UserState copyWith({bool? hasAudio, bool? hasVideo, bool? isOnline}) {
    return UserState(
      hasAudio: hasAudio ?? this.hasAudio,
      hasVideo: hasVideo ?? this.hasVideo,
      isOnline: isOnline ?? this.isOnline,
    );
  }
}

// import 'package:agora_rtc_engine/agora_rtc_engine.dart';
// import 'package:get/get.dart';
// import 'package:flutter/foundation.dart';
//
// class AgoraService extends GetxService {
//   static AgoraService get to => Get.find();
//
//   late RtcEngine _agoraEngine;
//   final _isInitialized = false.obs;
//   final _localUserId = 0.obs;
//
//   // Track states
//   final isJoined = false.obs;
//   final isAudioEnabled = true.obs;
//   final isVideoEnabled = false.obs;
//   final isScreenSharing = false.obs;
//   final isFrontCamera = true.obs;
//   final connectionState = ConnectionStateType.connectionStateDisconnected.obs;
//
//   // Remote users management
//   final remoteUsers = <int, RemoteUser>{}.obs;
//   final userStates = <int, UserState>{}.obs;
//
//   RtcEngine get engine => _agoraEngine;
//   int get localUserId => _localUserId.value;
//   bool get isInitialized => _isInitialized.value;
//
//   @override
//   void onInit() {
//     super.onInit();
//     debugPrint('=== AgoraService initialized ===');
//   }
//
//   @override
//   void onClose() {
//     _dispose();
//     super.onClose();
//   }
//
//   Future<void> initializeAgoraEngine() async {
//     try {
//       if (_isInitialized.value) {
//         debugPrint('=== Agora Engine already initialized ===');
//         return;
//       }
//
//       debugPrint('=== Initializing Agora Engine ===');
//
//       _agoraEngine = createAgoraRtcEngine();
//       await _agoraEngine.initialize(const RtcEngineContext(
//         appId: 'bc95ca12d08b4233babfb9a7803b59b7',
//         channelProfile: ChannelProfileType.channelProfileLiveBroadcasting,
//       ));
//
//       _registerEventHandlers();
//
//       // Enable video and audio
//       await _agoraEngine.enableVideo();
//       await _agoraEngine.enableAudio();
//
//       // Set video configuration for optimal quality
//       await _agoraEngine.setVideoEncoderConfiguration(
//         const VideoEncoderConfiguration(
//           dimensions: VideoDimensions(width: 640, height: 360),
//           frameRate: 15,
//           bitrate: 1000,
//           orientationMode: OrientationMode.orientationModeAdaptive,
//         ),
//       );
//
//       // Set default role
//       await _agoraEngine.setClientRole(role: ClientRoleType.clientRoleAudience);
//
//       _isInitialized.value = true;
//       debugPrint('=== Agora Engine initialized successfully ===');
//     } catch (e) {
//       debugPrint('=== Error initializing Agora Engine: $e ===');
//       rethrow;
//     }
//   }
//
//   void _registerEventHandlers() {
//     debugPrint('=== Registering Agora event handlers ===');
//
//     _agoraEngine.registerEventHandler(
//       RtcEngineEventHandler(
//         onConnectionStateChanged: (RtcConnection connection, ConnectionStateType state, ConnectionChangedReasonType reason) {
//           debugPrint('=== Connection state: $state, reason: $reason ===');
//           connectionState.value = state;
//         },
//
//         onJoinChannelSuccess: (RtcConnection connection, int elapsed) {
//           debugPrint('=== Joined channel successfully, UID: ${connection.localUid}, elapsed: $elapsed ===');
//           isJoined.value = true;
//           if (connection.localUid != null) {
//             _localUserId.value = connection.localUid!;
//           }
//         },
//
//         onUserJoined: (RtcConnection connection, int remoteUid, int elapsed) {
//           debugPrint('=== Remote user joined: $remoteUid ===');
//           remoteUsers[remoteUid] = RemoteUser(uid: remoteUid, name: 'User $remoteUid');
//           userStates[remoteUid] = UserState(
//             hasAudio: false,
//             hasVideo: false,
//             isOnline: true,
//           );
//         },
//
//         onUserOffline: (RtcConnection connection, int remoteUid, UserOfflineReasonType reason) {
//           debugPrint('=== Remote user offline: $remoteUid, reason: $reason ===');
//           remoteUsers.remove(remoteUid);
//           userStates.remove(remoteUid);
//         },
//
//         onRemoteAudioStateChanged: (RtcConnection connection, int remoteUid, RemoteAudioState state, RemoteAudioStateReason reason, int elapsed) {
//           debugPrint('=== User $remoteUid audio state: $state ===');
//           if (userStates.containsKey(remoteUid)) {
//             userStates[remoteUid] = userStates[remoteUid]!.copyWith(
//               hasAudio: state == RemoteAudioState.remoteAudioStateDecoding,
//             );
//           }
//         },
//
//         onRemoteVideoStateChanged: (RtcConnection connection, int remoteUid, RemoteVideoState state, RemoteVideoStateReason reason, int elapsed) {
//           debugPrint('=== User $remoteUid video state: $state ===');
//           if (userStates.containsKey(remoteUid)) {
//             userStates[remoteUid] = userStates[remoteUid]!.copyWith(
//               hasVideo: state == RemoteVideoState.remoteVideoStateDecoding,
//             );
//           }
//         },
//
//         onFirstRemoteVideoFrame: (RtcConnection connection, int remoteUid, int width, int height, int elapsed) {
//           debugPrint('=== First remote video frame from $remoteUid ($width x $height) ===');
//           if (userStates.containsKey(remoteUid)) {
//             userStates[remoteUid] = userStates[remoteUid]!.copyWith(hasVideo: true);
//           }
//         },
//
//         onError: (ErrorCodeType errorCode, String msg) {
//           debugPrint('=== Agora error: $errorCode, $msg ===');
//         },
//
//         onLeaveChannel: (RtcConnection connection, RtcStats stats) {
//           debugPrint('=== Left channel, duration: ${stats.duration}s ===');
//           isJoined.value = false;
//           remoteUsers.clear();
//           userStates.clear();
//         },
//
//         onLocalVideoStateChanged: (VideoSourceType source, LocalVideoStreamState state, LocalVideoStreamReason reason) {
//           debugPrint('=== Local video state: $state, reason: $reason ===');
//         },
//
//         onLocalAudioStateChanged: (RtcConnection connection, LocalAudioStreamState state, LocalAudioStreamReason reason) {
//           debugPrint('=== Local audio state: $state, reason: $reason ===');
//         },
//       ),
//     );
//   }
//   //
//   // Future<void> joinChannel({
//   //   required String token,
//   //   required String channelName,
//   //   required int uid,
//   //   required ClientRoleType role,
//   //  }) async {
//   //   try {
//   //     debugPrint('=== Joining channel: $channelName, uid: $uid, role: $role ===');
//   //
//   //     if (!_isInitialized.value) {
//   //       await initializeAgoraEngine();
//   //     }
//   //
//   //     if (isJoined.value) {
//   //       debugPrint('=== Already joined, leaving first ===');
//   //       await leaveChannel();
//   //       await Future.delayed(const Duration(milliseconds: 500));
//   //     }
//   //
//   //     // CRITICAL: Set local user ID BEFORE joining
//   //     _localUserId.value = uid;
//   //     debugPrint('=== Local user ID set to: $uid ===');
//   //
//   //     // Set client role
//   //     await _agoraEngine.setClientRole(role: role);
//   //
//   //     // For broadcasters, enable video BEFORE joining
//   //     if (role == ClientRoleType.clientRoleBroadcaster) {
//   //       debugPrint('=== Enabling video for broadcaster ===');
//   //       await _agoraEngine.enableVideo();
//   //       await _agoraEngine.enableLocalVideo(true);
//   //       isVideoEnabled.value = true;
//   //     }
//   //
//   //     final options = ChannelMediaOptions(
//   //       channelProfile: ChannelProfileType.channelProfileLiveBroadcasting,
//   //       clientRoleType: role,
//   //       autoSubscribeAudio: true,
//   //       autoSubscribeVideo: true,
//   //       publishCameraTrack: role == ClientRoleType.clientRoleBroadcaster,
//   //       publishMicrophoneTrack: role == ClientRoleType.clientRoleBroadcaster,
//   //     );
//   //
//   //     await _agoraEngine.joinChannel(
//   //       token: token,
//   //       channelId: channelName,
//   //       uid: uid,
//   //       options: options,
//   //     );
//   //
//   //     // Start preview AFTER joining for broadcaster
//   //     if (role == ClientRoleType.clientRoleBroadcaster) {
//   //       await Future.delayed(const Duration(milliseconds: 300));
//   //       await _agoraEngine.startPreview();
//   //       debugPrint('=== Preview started for broadcaster ===');
//   //     }
//   //
//   //     debugPrint('=== Channel join request sent ===');
//   //   } catch (e) {
//   //     debugPrint('=== Error joining channel: $e ===');
//   //     rethrow;
//   //   }
//   // }
//
//   Future<void> joinChannel({
//     required String token,
//     required String channelName,
//     required int uid,
//     required ClientRoleType role,
//   }) async {
//     try {
//       debugPrint('=== Joining channel: $channelName, uid: $uid, role: $role ===');
//
//       if (!_isInitialized.value) {
//         await initializeAgoraEngine();
//       }
//
//       if (isJoined.value) {
//         debugPrint('=== Already joined, leaving first ===');
//         await leaveChannel();
//         await Future.delayed(const Duration(milliseconds: 500));
//       }
//
//       // Set local user ID
//       _localUserId.value = uid;
//       debugPrint('=== Local user ID set to: $uid ===');
//
//       // Set client role
//       await _agoraEngine.setClientRole(role: role);
//
//       final options = ChannelMediaOptions(
//         channelProfile: ChannelProfileType.channelProfileLiveBroadcasting,
//         clientRoleType: role,
//         autoSubscribeAudio: true,
//         autoSubscribeVideo: true,
//         publishCameraTrack: role == ClientRoleType.clientRoleBroadcaster,
//         publishMicrophoneTrack: role == ClientRoleType.clientRoleBroadcaster,
//       );
//
//       // JOIN CHANNEL FIRST
//       await _agoraEngine.joinChannel(
//         token: token,
//         channelId: channelName,
//         uid: uid,
//         options: options,
//       );
//
//       // THEN START PREVIEW FOR BROADCASTER
//       if (role == ClientRoleType.clientRoleBroadcaster) {
//         await _agoraEngine.enableVideo();
//         await _agoraEngine.enableLocalVideo(true);
//         await Future.delayed(const Duration(milliseconds: 300));
//         await _agoraEngine.startPreview();
//         isVideoEnabled.value = true;
//         debugPrint('=== Video preview started AFTER joinChannel ===');
//       }
//
//       debugPrint('=== Channel join request sent ===');
//     } catch (e) {
//       debugPrint('=== Error joining channel: $e ===');
//       rethrow;
//     }
//   }
//
//   Future<void> leaveChannel() async {
//     try {
//       debugPrint('=== Leaving channel ===');
//
//       // Stop preview if running
//       await _agoraEngine.stopPreview();
//
//       // Leave channel
//       await _agoraEngine.leaveChannel();
//
//       // Reset states
//       isJoined.value = false;
//       isVideoEnabled.value = false;
//       isAudioEnabled.value = true;
//       isScreenSharing.value = false;
//       remoteUsers.clear();
//       userStates.clear();
//
//       debugPrint('=== Channel left successfully ===');
//     } catch (e) {
//       debugPrint('=== Error leaving channel: $e ===');
//     }
//   }
//
//   Future<void> toggleAudio() async {
//     try {
//       if (!isJoined.value) {
//         debugPrint('=== Cannot toggle audio - not joined ===');
//         return;
//       }
//
//       final newState = !isAudioEnabled.value;
//       await _agoraEngine.muteLocalAudioStream(!newState);
//       await _agoraEngine.enableLocalAudio(newState);
//       isAudioEnabled.value = newState;
//       debugPrint('=== Audio toggled: $newState ===');
//     } catch (e) {
//       debugPrint('=== Error toggling audio: $e ===');
//       rethrow;
//     }
//   }
//
//   Future<void> toggleVideo() async {
//     try {
//       if (!isJoined.value) {
//         debugPrint('=== Cannot toggle video - not joined ===');
//         return;
//       }
//
//       if (isScreenSharing.value) {
//         debugPrint('=== Cannot toggle video while screen sharing ===');
//         return;
//       }
//
//       final newState = !isVideoEnabled.value;
//       debugPrint('=== Toggling video from ${isVideoEnabled.value} to $newState ===');
//
//       if (newState) {
//         // RE-ENABLE VIDEO MODULE
//         await _agoraEngine.enableVideo();
//         await _agoraEngine.enableLocalVideo(true);
//         await _agoraEngine.muteLocalVideoStream(false);
//         await _agoraEngine.startPreview();
//         debugPrint('=== Video enabled and preview started ===');
//       } else {
//         await _agoraEngine.muteLocalVideoStream(true);
//         await _agoraEngine.stopPreview();
//         // DO NOT CALL enableLocalVideo(false) — it disables the module
//       }
//
//       isVideoEnabled.value = newState;
//       debugPrint('=== Video toggled: $newState ===');
//     } catch (e) {
//       debugPrint('=== Error toggling video: $e ===');
//       rethrow;
//     }
//   }
//
//   Future<void> startScreenSharing() async {
//     try {
//       if (!isJoined.value) {
//         debugPrint('=== Cannot start screen share - not joined ===');
//         return;
//       }
//
//       debugPrint('=== Starting screen sharing ===');
//
//       // Disable camera video if it's on
//       if (isVideoEnabled.value) {
//         await _agoraEngine.muteLocalVideoStream(true);
//         await _agoraEngine.stopPreview();
//       }
//
//       await _agoraEngine.startScreenCapture(
//         const ScreenCaptureParameters2(
//           captureAudio: true,
//           captureVideo: true,
//         ),
//       );
//
//       isScreenSharing.value = true;
//       debugPrint('=== Screen sharing started successfully ===');
//     } catch (e) {
//       debugPrint('=== Error starting screen sharing: $e ===');
//       rethrow;
//     }
//   }
//
//   Future<void> stopScreenSharing() async {
//     try {
//       if (!isJoined.value) return;
//
//       debugPrint('=== Stopping screen sharing ===');
//       await _agoraEngine.stopScreenCapture();
//
//       // Re-enable camera if it was on before
//       if (isVideoEnabled.value) {
//         await _agoraEngine.muteLocalVideoStream(false);
//         await _agoraEngine.startPreview();
//       }
//
//       isScreenSharing.value = false;
//       debugPrint('=== Screen sharing stopped ===');
//     } catch (e) {
//       debugPrint('=== Error stopping screen sharing: $e ===');
//     }
//   }
//
//   Future<void> switchCamera() async {
//     try {
//       if (!isJoined.value) {
//         debugPrint('=== Cannot switch camera - not joined ===');
//         return;
//       }
//
//       if (!isVideoEnabled.value) {
//         debugPrint('=== Cannot switch camera - video disabled ===');
//         return;
//       }
//
//       await _agoraEngine.switchCamera();
//       isFrontCamera.value = !isFrontCamera.value;
//       debugPrint('=== Camera switched to ${isFrontCamera.value ? "front" : "back"} ===');
//     } catch (e) {
//       debugPrint('=== Error switching camera: $e ===');
//       rethrow;
//     }
//   }
//
//   void _dispose() {
//     try {
//       debugPrint('=== Disposing Agora Engine ===');
//       if (_isInitialized.value) {
//         _agoraEngine.leaveChannel();
//         _agoraEngine.release();
//         _isInitialized.value = false;
//       }
//     } catch (e) {
//       debugPrint('=== Error disposing Agora Engine: $e ===');
//     }
//   }
//
//   List<int> get remoteUserIds => remoteUsers.keys.toList();
//   int get totalParticipants => remoteUsers.length + (isJoined.value ? 1 : 0);
// }
//
// // Data models
// class RemoteUser {
//   final int uid;
//   final String name;
//
//   RemoteUser({required this.uid, required this.name});
// }
//
// class UserState {
//   final bool hasAudio;
//   final bool hasVideo;
//   final bool isOnline;
//
//   UserState({
//     required this.hasAudio,
//     required this.hasVideo,
//     required this.isOnline,
//   });
//
//   UserState copyWith({
//     bool? hasAudio,
//     bool? hasVideo,
//     bool? isOnline,
//   }) {
//     return UserState(
//       hasAudio: hasAudio ?? this.hasAudio,
//       hasVideo: hasVideo ?? this.hasVideo,
//       isOnline: isOnline ?? this.isOnline,
//     );
//   }
// }
// // import 'package:agora_rtc_engine/agora_rtc_engine.dart';
// // import 'package:get/get.dart';
// //
// // class AgoraService extends GetxService {
// //   static AgoraService get to => Get.find();
// //
// //   late RtcEngine _agoraEngine;
// //   final _isInitialized = false.obs;
// //   final _localUserId = 0.obs;
// //
// //   // Track states
// //   final isJoined = false.obs;
// //   final isAudioEnabled = true.obs;
// //   final isVideoEnabled = false.obs;
// //   final isScreenSharing = false.obs;
// //   final connectionState = ConnectionStateType.connectionStateDisconnected.obs;
// //
// //   // Remote users management
// //   final remoteUsers = <int, RemoteUser>{}.obs;
// //   final userStates = <int, UserState>{}.obs;
// //
// //   RtcEngine get engine => _agoraEngine;
// //
// //   // Getter for local user ID
// //   int get localUserId => _localUserId.value;
// //
// //   @override
// //   void onInit() {
// //     super.onInit();
// //     print('=== AgoraService initialized ===');
// //   }
// //
// //   @override
// //   void onClose() {
// //     _dispose();
// //     super.onClose();
// //   }
// //
// //   Future<void> initializeAgoraEngine() async {
// //     try {
// //       print('=== Initializing Agora Engine ===');
// //
// //       // Create engine instance
// //       _agoraEngine = createAgoraRtcEngine();
// //       await _agoraEngine.initialize(const RtcEngineContext(
// //         appId: 'bc95ca12d08b4233babfb9a7803b59b7',
// //       ));
// //
// //       // Register event handlers
// //       _registerEventHandlers();
// //
// //       // Enable video
// //       await _agoraEngine.enableVideo();
// //
// //       // Set channel profile
// //       await _agoraEngine.setChannelProfile(ChannelProfileType.channelProfileLiveBroadcasting);
// //
// //       // Set client role (will be updated based on user role)
// //       await _agoraEngine.setClientRole(role: ClientRoleType.clientRoleAudience);
// //
// //       _isInitialized.value = true;
// //       print('=== Agora Engine initialized successfully ===');
// //     } catch (e) {
// //       print('=== Error initializing Agora Engine: $e ===');
// //       rethrow;
// //     }
// //   }
// //
// //   void _registerEventHandlers() {
// //     print('=== Registering Agora event handlers ===');
// //
// //     _agoraEngine.registerEventHandler(
// //       RtcEngineEventHandler(
// //         onConnectionStateChanged: (RtcConnection connection, ConnectionStateType state, ConnectionChangedReasonType reason) {
// //           print('=== Connection state changed: $state, reason: $reason ===');
// //           connectionState.value = state;
// //         },
// //         onJoinChannelSuccess: (RtcConnection connection, int elapsed) {
// //           print('=== Joined channel successfully, elapsed: $elapsed ===');
// //           isJoined.value = true;
// //           _localUserId.value = connection.localUid ?? 0;
// //         },
// //         onUserJoined: (RtcConnection connection, int remoteUid, int elapsed) {
// //           print('=== Remote user joined: $remoteUid ===');
// //           remoteUsers[remoteUid] = RemoteUser(uid: remoteUid);
// //           userStates[remoteUid] = UserState(hasAudio: false, hasVideo: false, isOnline: true);
// //           print('=== Total remote users now: ${remoteUsers.length} ===');
// //         },
// //         onUserOffline: (RtcConnection connection, int remoteUid, UserOfflineReasonType reason) {
// //           print('=== Remote user offline: $remoteUid, reason: $reason ===');
// //           remoteUsers.remove(remoteUid);
// //           userStates.remove(remoteUid);
// //           print('=== Total remote users now: ${remoteUsers.length} ===');
// //         },
// //         onUserMuteAudio: (RtcConnection connection, int remoteUid, bool muted) {
// //           print('=== User $remoteUid audio muted: $muted ===');
// //           if (userStates.containsKey(remoteUid)) {
// //             userStates[remoteUid] = userStates[remoteUid]!.copyWith(hasAudio: !muted);
// //           }
// //         },
// //         onUserMuteVideo: (RtcConnection connection, int remoteUid, bool muted) {
// //           print('=== User $remoteUid video muted: $muted ===');
// //           if (userStates.containsKey(remoteUid)) {
// //             userStates[remoteUid] = userStates[remoteUid]!.copyWith(hasVideo: !muted);
// //           }
// //         },
// //         onFirstRemoteVideoFrame: (RtcConnection connection, int remoteUid, int width, int height, int elapsed) {
// //           print('=== First remote video frame from $remoteUid ===');
// //           if (userStates.containsKey(remoteUid)) {
// //             userStates[remoteUid] = userStates[remoteUid]!.copyWith(hasVideo: true);
// //           }
// //         },
// //         onFirstRemoteAudioFrame: (RtcConnection connection, int remoteUid, int elapsed) {
// //           print('=== First remote audio frame from $remoteUid ===');
// //           if (userStates.containsKey(remoteUid)) {
// //             userStates[remoteUid] = userStates[remoteUid]!.copyWith(hasAudio: true);
// //           }
// //         },
// //         onError: (ErrorCodeType errorCode, String msg) {
// //           print('=== Agora error: $errorCode, $msg ===');
// //         },
// //         onLeaveChannel: (RtcConnection connection, RtcStats stats) {
// //           print('=== Left channel ===');
// //           isJoined.value = false;
// //           remoteUsers.clear();
// //           userStates.clear();
// //         },
// //       ),
// //     );
// //   }
// //
// //   Future<void> joinChannel({
// //     required String token,
// //     required String channelName,
// //     required int uid,
// //     required ClientRoleType role,
// //   }) async {
// //     try {
// //       print('=== Joining channel: $channelName, uid: $uid, role: $role ===');
// //       print('=== Token first 20 chars: ${token.substring(0, 20)}... ===');
// //       print('=== Current joined status: ${isJoined.value} ===');
// //
// //       if (!_isInitialized.value) {
// //         await initializeAgoraEngine();
// //       }
// //
// //       // If already joined, leave first with proper cleanup
// //       if (isJoined.value) {
// //         print('=== Already joined to a channel, leaving first ===');
// //         await leaveChannel();
// //         await Future.delayed(Duration(milliseconds: 1000)); // Increased delay
// //       }
// //
// //       // Set client role based on user type
// //       await _agoraEngine.setClientRole(role: role);
// //
// //       // Join channel with CORRECT parameters
// //       await _agoraEngine.joinChannel(
// //         token: token,
// //         channelId: channelName,
// //         uid: uid,
// //         options: const ChannelMediaOptions(
// //           channelProfile: ChannelProfileType.channelProfileLiveBroadcasting,
// //           clientRoleType: ClientRoleType.clientRoleAudience,
// //           autoSubscribeAudio: true,
// //           autoSubscribeVideo: true,
// //         ),
// //       );
// //
// //       print('=== Channel join request sent for: $channelName ===');
// //     } catch (e) {
// //       print('=== Error joining channel: $e ===');
// //
// //       // Handle error -17 specifically
// //       if (e.toString().contains('-17')) {
// //         print('=== Error -17 detected, performing full cleanup and retry ===');
// //         await _fullCleanup();
// //         await Future.delayed(Duration(seconds: 2));
// //
// //         // Retry join
// //         await _agoraEngine.joinChannel(
// //           token: token,
// //           channelId: channelName,
// //           uid: uid,
// //           options: const ChannelMediaOptions(
// //             channelProfile: ChannelProfileType.channelProfileLiveBroadcasting,
// //             clientRoleType: ClientRoleType.clientRoleAudience,
// //             autoSubscribeAudio: true,
// //             autoSubscribeVideo: true,
// //           ),
// //         );
// //       } else {
// //         rethrow;
// //       }
// //     }
// //   }
// //
// //   Future<void> _fullCleanup() async {
// //     try {
// //       print('=== Performing full cleanup ===');
// //       await leaveChannel();
// //       await _agoraEngine.release();
// //       _isInitialized.value = false;
// //       await initializeAgoraEngine();
// //       print('=== Full cleanup completed ===');
// //     } catch (e) {
// //       print('=== Error during full cleanup: $e ===');
// //     }
// //   }
// //
// //   Future<void> leaveChannel() async {
// //     try {
// //       print('=== Leaving channel ===');
// //
// //       await _agoraEngine.leaveChannel();
// //
// //       // Stop and disable local media
// //       await _disableLocalMedia();
// //
// //       isJoined.value = false;
// //       remoteUsers.clear();
// //       userStates.clear();
// //       isScreenSharing.value = false;
// //       isVideoEnabled.value = false;
// //
// //       print('=== Channel left successfully ===');
// //     } catch (e) {
// //       print('=== Error leaving channel: $e ===');
// //       rethrow;
// //     }
// //   }
// //
// //   Future<void> toggleAudio() async {
// //     try {
// //       if (!isJoined.value) return;
// //
// //       await _agoraEngine.muteLocalAudioStream(!isAudioEnabled.value);
// //       isAudioEnabled.value = !isAudioEnabled.value;
// //       print('=== Audio toggled: ${isAudioEnabled.value} ===');
// //     } catch (e) {
// //       print('=== Error toggling audio: $e ===');
// //     }
// //   }
// //
// //   Future<void> toggleVideo() async {
// //     try {
// //       if (!isJoined.value) return;
// //
// //       if (isScreenSharing.value) {
// //         print('=== Cannot toggle video while screen sharing ===');
// //         return;
// //       }
// //
// //       await _agoraEngine.muteLocalVideoStream(!isVideoEnabled.value);
// //       isVideoEnabled.value = !isVideoEnabled.value;
// //       print('=== Video toggled: ${isVideoEnabled.value} ===');
// //     } catch (e) {
// //       print('=== Error toggling video: $e ===');
// //     }
// //   }
// //
// //   Future<void> startScreenSharing() async {
// //     try {
// //       if (!isJoined.value) return;
// //
// //       print('=== Starting screen sharing ===');
// //
// //       await _agoraEngine.startScreenCapture(
// //         const ScreenCaptureParameters2(
// //           captureAudio: true,
// //           captureVideo: true,
// //         ),
// //       );
// //
// //       isScreenSharing.value = true;
// //       print('=== Screen sharing started ===');
// //     } catch (e) {
// //       print('=== Error starting screen sharing: $e ===');
// //       rethrow;
// //     }
// //   }
// //
// //   Future<void> stopScreenSharing() async {
// //     try {
// //       if (!isJoined.value) return;
// //
// //       print('=== Stopping screen sharing ===');
// //
// //       await _agoraEngine.stopScreenCapture();
// //       isScreenSharing.value = false;
// //
// //       print('=== Screen sharing stopped ===');
// //     } catch (e) {
// //       print('=== Error stopping screen sharing: $e ===');
// //       rethrow;
// //     }
// //   }
// //
// //   Future<void> switchCamera() async {
// //     try {
// //       if (!isJoined.value || !isVideoEnabled.value) return;
// //
// //       await _agoraEngine.switchCamera();
// //       print('=== Camera switched ===');
// //     } catch (e) {
// //       print('=== Error switching camera: $e ===');
// //     }
// //   }
// //
// //   Future<void> _disableLocalMedia() async {
// //     try {
// //       if (isVideoEnabled.value) {
// //         await _agoraEngine.muteLocalVideoStream(true);
// //       }
// //       if (isAudioEnabled.value) {
// //         await _agoraEngine.muteLocalAudioStream(true);
// //       }
// //       if (isScreenSharing.value) {
// //         await _agoraEngine.stopScreenCapture();
// //       }
// //     } catch (e) {
// //       print('=== Error disabling local media: $e ===');
// //     }
// //   }
// //
// //   void _dispose() {
// //     try {
// //       print('=== Disposing Agora Engine ===');
// //       _agoraEngine.leaveChannel();
// //       _agoraEngine.release();
// //       _isInitialized.value = false;
// //     } catch (e) {
// //       print('=== Error disposing Agora Engine: $e ===');
// //     }
// //   }
// //
// //   // Getters
// //   bool get isInitialized => _isInitialized.value;
// //   List<int> get remoteUserIds => remoteUsers.keys.toList();
// //   int get totalParticipants => remoteUsers.length + (isJoined.value ? 1 : 0);
// // }
// //
// // // Data models
// // class RemoteUser {
// //   final int uid;
// //
// //   RemoteUser({required this.uid});
// // }
// //
// // class UserState {
// //   final bool hasAudio;
// //   final bool hasVideo;
// //   final bool isOnline;
// //
// //   UserState({
// //     required this.hasAudio,
// //     required this.hasVideo,
// //     required this.isOnline,
// //   });
// //
// //   UserState copyWith({
// //     bool? hasAudio,
// //     bool? hasVideo,
// //     bool? isOnline,
// //   }) {
// //     return UserState(
// //       hasAudio: hasAudio ?? this.hasAudio,
// //       hasVideo: hasVideo ?? this.hasVideo,
// //       isOnline: isOnline ?? this.isOnline,
// //     );
// //   }
// // }
// //
