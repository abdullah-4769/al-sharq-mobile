// interactive_venue_map.dart
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart';
import 'package:al_sharq_conference/app_colors/app_colors.dart';

import '../../data/response_models/organizer_response_models/organizer_venue_show_model.dart';

class VenueMapComponent extends StatefulWidget {
  final List<OrganizerVenueShowEvent> events;
  final Function(OrganizerVenueShowEvent)? onMarkerTap;

  const VenueMapComponent({
    Key? key,
    required this.events,
    this.onMarkerTap,
  }) : super(key: key);

  @override
  State<VenueMapComponent> createState() => _VenueMapComponentState();
}

class _VenueMapComponentState extends State<VenueMapComponent> {
  MapboxMap? mapboxMap;
  bool _isMapLoading = true;
  bool _isMapCreated = false;

  List<OrganizerVenueShowEvent> _eventsWithLocations = [];

  PointAnnotationManager? _pointAnnotationManager;

  static const String mapStyle = 'mapbox://styles/mapbox/streets-v12';

  @override
  void initState() {
    super.initState();
    _filterEventsWithLocations();
    _initializeMap();
  }

  void _filterEventsWithLocations() {
    _eventsWithLocations = widget.events.where((e) => e.getLatLngFromUrl() != null).toList();
  }

  void _initializeMap() {
    setState(() => _isMapLoading = false);
  }

  /// ---------------------------
  /// MAP CREATED
  /// ---------------------------
  void _onMapCreated(MapboxMap map) async {
    mapboxMap = map;

    _pointAnnotationManager = await map.annotations.createPointAnnotationManager();

    setState(() => _isMapCreated = true);

    _addMarkersToMap();
    _fitMapToMarkers();
  }

  /// ---------------------------
  /// ADD MARKERS
  /// ---------------------------
  Future<void> _addMarkersToMap() async {
    if (_pointAnnotationManager == null) return;
    if (_eventsWithLocations.isEmpty) return;

    await _pointAnnotationManager!.deleteAll();

    Uint8List? markerImage;

    try {
      final bytes = await rootBundle.load('assets/images/map_marker.png');
      markerImage = bytes.buffer.asUint8List();
    } catch (_) {}

    List<PointAnnotationOptions> options = [];

    for (var event in _eventsWithLocations) {
      final loc = event.getLatLngFromUrl();
      if (loc == null) continue;

      final opts = PointAnnotationOptions(
        geometry: Point(coordinates: Position(loc.longitude, loc.latitude)),
        iconAnchor: IconAnchor.BOTTOM,
        textField: event.name,
        textSize: 12,
        textColor: Colors.white.value,
        textHaloColor: Colors.black.value,
        textHaloWidth: 2,
        textOffset: [0, -2],
        image: markerImage,
      );

      options.add(opts);
    }

    await _pointAnnotationManager!.createMulti(options);

    _setupAnnotationListeners();
  }

  /// ---------------------------
  /// ANNOTATION TAPS
  /// ---------------------------
  void _setupAnnotationListeners() {
    _pointAnnotationManager?.addOnPointAnnotationClickListener(
      MyPointAnnotationClickListener((annotation) {
        _onAnnotationTap(annotation);
      }),
    );
  }

  void _onAnnotationTap(PointAnnotation annotation) {
    final annotationPoint = annotation.geometry;
    if (annotationPoint == null) return;

    for (var event in _eventsWithLocations) {
      final eventLocation = event.getLatLngFromUrl();
      if (eventLocation == null) continue;

      double distance = _calculateDistance(
        annotationPoint.coordinates.lat.toDouble(),
        annotationPoint.coordinates.lng.toDouble(),
        eventLocation.latitude,
        eventLocation.longitude,
      );

      if (distance < 0.0009) {
        widget.onMarkerTap?.call(event);
        return;
      }
    }
  }

  double _calculateDistance(double lat1, double lng1, double lat2, double lng2) {
    return ((lat1 - lat2) * (lat1 - lat2) + (lng1 - lng2) * (lng1 - lng2)).abs();
  }

  /// ---------------------------
  /// FIT MAP TO ALL MARKERS
  /// ---------------------------
  Future<void> _fitMapToMarkers() async {
    if (mapboxMap == null || _eventsWithLocations.isEmpty) return;

    final points = _eventsWithLocations
        .map((e) => e.getLatLngFromUrl())
        .where((p) => p != null)
        .map((p) => Position(p!.longitude, p.latitude))
        .toList();

    if (points.isEmpty) return;

    // Calculate bounds manually
    double minLat = points.first.lat.toDouble();
    double maxLat = points.first.lat.toDouble();
    double minLng = points.first.lng.toDouble();
    double maxLng = points.first.lng.toDouble();

    for (var p in points) {
      final lat = p.lat.toDouble();
      final lng = p.lng.toDouble();
      if (lat < minLat) minLat = lat;
      if (lat > maxLat) maxLat = lat;
      if (lng < minLng) minLng = lng;
      if (lng > maxLng) maxLng = lng;
    }

    double centerLat = (minLat + maxLat) / 2;
    double centerLng = (minLng + maxLng) / 2;

    // Approx zoom calculation
    double latDiff = (maxLat - minLat).abs();
    double lngDiff = (maxLng - minLng).abs();
    double maxDiff = latDiff > lngDiff ? latDiff : lngDiff;

    // Adjust zoom based on spread
    double zoom = 12;
    if (maxDiff > 0.5) zoom = 9;
    else if (maxDiff > 0.2) zoom = 10;
    else if (maxDiff > 0.1) zoom = 11;
    else zoom = 13;

    await mapboxMap?.flyTo(
      CameraOptions(
        center: Point(coordinates: Position(centerLng, centerLat)),
        zoom: zoom,
      ),
      MapAnimationOptions(duration: 1200),
    );
  }



  /// ---------------------------
  /// UI BUILDERS
  /// ---------------------------
  @override
  Widget build(BuildContext context) {
    if (_isMapLoading) return _buildLoadingState();

    if (_eventsWithLocations.isEmpty) return _buildNoLocationsState();

    return Container(
      height: 300,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 8, offset: Offset(0, 2)),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Stack(
          children: [
            MapWidget(
              key: ValueKey('map_${_eventsWithLocations.length}'),
              onMapCreated: _onMapCreated,
              styleUri: mapStyle,
              cameraOptions: CameraOptions(
                center: Point(coordinates: Position(74.3239107, 31.5188399)),
                zoom: 11,
              ),
            ),

            if (_isMapCreated) _buildControls(),
            if (_isMapCreated) _buildAttribution(),
          ],
        ),
      ),
    );
  }

  Widget _buildControls() {
    return Positioned(
      right: 16,
      bottom: 16,
      child: Column(
        children: [
          FloatingActionButton.small(
            heroTag: 'in',
            onPressed: () async {
              final state = await mapboxMap?.getCameraState();
              if (state != null) {
                mapboxMap?.setCamera(CameraOptions(zoom: state.zoom + 1));
              }
            },
            backgroundColor: Colors.white,
            child: Icon(Icons.add, color: Colors.black),
          ),
          SizedBox(height: 8),
          FloatingActionButton.small(
            heroTag: 'out',
            onPressed: () async {
              final state = await mapboxMap?.getCameraState();
              if (state != null && state.zoom > 5) {
                mapboxMap?.setCamera(CameraOptions(zoom: state.zoom - 1));
              }
            },
            backgroundColor: Colors.white,
            child: Icon(Icons.remove, color: Colors.black),
          ),
          SizedBox(height: 8),
          FloatingActionButton.small(
            heroTag: 'fit',
            onPressed: _fitMapToMarkers,
            backgroundColor: Colors.white,
            child: Icon(Icons.my_location, color: Colors.black),
          ),
        ],
      ),
    );
  }

  Widget _buildAttribution() {
    return Positioned(
      bottom: 8,
      left: 8,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(4),
        ),
        child: Text('© Mapbox', style: TextStyle(fontSize: 10, color: Colors.grey)),
      ),
    );
  }

  Widget _buildLoadingState() {
    return Container(
      height: 300,
      alignment: Alignment.center,
      child: CircularProgressIndicator(color: AppColors.primaryColor),
    );
  }

  Widget _buildNoLocationsState() {
    return Container(
      height: 300,
      alignment: Alignment.center,
      child: Text("No event locations found"),
    );
  }

  @override
  void dispose() {
    mapboxMap?.dispose();
    super.dispose();
  }
}

class MyPointAnnotationClickListener extends OnPointAnnotationClickListener {
  final Function(PointAnnotation) onClick;

  MyPointAnnotationClickListener(this.onClick);

  @override
  void onPointAnnotationClick(PointAnnotation annotation) {
    onClick(annotation);
  }
}
