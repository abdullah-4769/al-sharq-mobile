import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:al_sharq_conference/app_colors/app_colors.dart';
import '../../data/response_models/organizer_response_models/organizer_venue_show_model.dart';

class VenueMapComponent extends StatefulWidget {
  final List<OrganizerVenueShowEvent> events;
  final Function(OrganizerVenueShowEvent)? onMarkerTap;

  const VenueMapComponent({
    Key? key,
    required this.events,
    this.onMarkerTap,
  }) : super(key: key);

  @override
  State<VenueMapComponent> createState() => _VenueMapComponentState();
}

class _VenueMapComponentState extends State<VenueMapComponent> {
  GoogleMapController? _mapController;
  Set<Marker> _markers = {};
  LatLng _center = const LatLng(31.5188399, 74.3239107); // Default Lahore

  @override
  void initState() {
    super.initState();
    _setupMarkers();
  }

  void _setupMarkers() {
    final markers = <Marker>{};
    LatLng? firstValidLocation;

    for (var event in widget.events) {
      final location = event.getLatLngFromUrl();
      if (location != null) {
        firstValidLocation ??= location;

        markers.add(
          Marker(
            markerId: MarkerId('event_${event.id}'),
            position: location,
            infoWindow: InfoWindow(
              title: event.name,
              snippet: '${event.totalSessions} sessions',
              onTap: () {
                widget.onMarkerTap?.call(event);
              },
            ),
            icon: BitmapDescriptor.defaultMarkerWithHue(
              BitmapDescriptor.hueRed,
            ),
          ),
        );
      }
    }

    setState(() {
      _markers = markers;
      if (firstValidLocation != null) {
        _center = firstValidLocation;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_markers.isEmpty) {
      return Container(
        height: 300,
        decoration: BoxDecoration(
          color: Colors.grey[200],
          borderRadius: BorderRadius.circular(12),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.map_outlined, size: 50, color: Colors.grey[400]),
              const SizedBox(height: 8),
              Text(
                'No valid locations to display',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey[600],
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Container(
      height: 300,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: GoogleMap(
          initialCameraPosition: CameraPosition(
            target: _center,
            zoom: 12,
          ),
          markers: _markers,
          onMapCreated: (controller) {
            _mapController = controller;
          },
          myLocationButtonEnabled: true,
          myLocationEnabled: true,
          zoomControlsEnabled: true,
          mapType: MapType.normal,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _mapController?.dispose();
    super.dispose();
  }
}
